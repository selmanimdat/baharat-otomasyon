import zipfile
import os

def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        # Exclude directories in-place to prevent os.walk from entering them
        dirs[:] = [d for d in dirs if d not in ('node_modules', '.git', '.expo', 'web-build')]
        for file in files:
            filepath = os.path.join(root, file)
            arcname = os.path.relpath(filepath, path)
            ziph.write(filepath, arcname)

output_zip = '/opt/baharat otomasyon/static/react_native_expo_app.zip'
with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir('.', zipf)
print("React Native app zipped successfully to:", output_zip)
