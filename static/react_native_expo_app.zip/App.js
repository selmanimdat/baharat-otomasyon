import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  View,
  Text,
  SafeAreaView,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  ActivityIndicator,
  Vibration,
  Alert,
  LogBox,
} from 'react-native';
import TcpSocket from 'react-native-tcp-socket';
import { api } from './api';

LogBox.ignoreAllLogs();

export default function App() {
  // Navigation & User State
  const [screen, setScreen] = useState('login'); // login, station-select, job-queue, checklist, packaging, admin
  const [user, setUser] = useState(null);
  const [db, setDb] = useState({ users: [], scales: [], firms: [], recipes: [], orders: [], logs: [] });
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);

  // Authentication Fields
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [roleInput, setRoleInput] = useState('operator'); // operator, manager, secretary

  // Scale Connection State
  const [selectedScale, setSelectedScale] = useState(null);
  const [connected, setConnected] = useState(false);
  const [weight, setWeight] = useState(0.0);
  const [logs, setLogs] = useState([]);
  const [showLogs, setShowLogs] = useState(false);

  // Active Job State
  const [activeJob, setActiveJob] = useState(null); // { order, batch }
  const [activeWeighingItem, setActiveWeighingItem] = useState(null); // { name, targetAmount, tolerance }
  const [isInRange, setIsInRange] = useState(false);

  // Admin Forms State
  const [adminTab, setAdminTab] = useState('scales'); // scales, firms, recipes, logs, users
  const [newScaleName, setNewScaleName] = useState('');
  const [newScaleIp, setNewScaleIp] = useState('');
  const [newScalePort, setNewScalePort] = useState('8899');
  const [newScaleIsSim, setNewScaleIsSim] = useState(false);

  const [newFirmName, setNewFirmName] = useState('');

  const [newRecipeName, setNewRecipeName] = useState('');
  const [newRecipeFirmId, setNewRecipeFirmId] = useState('');
  const [newIngredientName, setNewIngredientName] = useState('');
  const [newIngredientAmount, setNewIngredientAmount] = useState('');
  const [newIngredientTolerance, setNewIngredientTolerance] = useState('');
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  const [newOrderFirm, setNewOrderFirm] = useState('');
  const [newOrderRecipe, setNewOrderRecipe] = useState('');
  const [newOrderAmount, setNewOrderAmount] = useState('');
  const [newOrderBagWeight, setNewOrderBagWeight] = useState('20.0');

  const [newUserName, setNewUserName] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState('operator');

  const socketRef = useRef(null);
  const simulatorIntervalRef = useRef(null);
  const activeJobRef = useRef(null);

  useEffect(() => {
    activeJobRef.current = activeJob;
  }, [activeJob]);

  // Logging Helper
  const addLog = (msg) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs((prev) => [`[${timestamp}] ${msg}`, ...prev].slice(0, 50));
    console.log(msg);
  };

  // Database Synchronization
  const fetchDb = async () => {
    try {
      const data = await api.getDatabase();
      setDb(data);

      // Sync active job state with refreshed DB
      if (activeJobRef.current) {
        const oId = activeJobRef.current.order.id;
        const bId = activeJobRef.current.batch.id;
        const freshOrder = data.orders.find((o) => o.id === oId);
        const freshBatch = freshOrder ? freshOrder.batches.find((b) => b.id === bId) : null;
        if (freshOrder && freshBatch) {
          setActiveJob({ order: freshOrder, batch: freshBatch });
          if (freshBatch.status === 'paketlemede' && screen === 'checklist') {
            setScreen('packaging');
          }
        } else {
          setActiveJob(null);
          setScreen('job-queue');
        }
      }
    } catch (err) {
      console.error('Failed to sync DB:', err);
    }
  };

  // Periodically Poll Server when logged in
  useEffect(() => {
    let interval = null;
    if (user) {
      fetchDb();
      interval = setInterval(fetchDb, 3000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [user, screen]);

  // Haptic feedback when weight is within correct tolerance bounds
  useEffect(() => {
    if (activeWeighingItem) {
      const target = activeWeighingItem.targetAmount;
      const tol = activeWeighingItem.tolerance;
      const inRange = weight >= target - tol && weight <= target + tol;

      if (inRange && !isInRange) {
        Vibration.vibrate([0, 150, 50, 150]);
      }
      setIsInRange(inRange);
    } else {
      setIsInRange(false);
    }
  }, [weight, activeWeighingItem]);

  // TCP Scale / Simulator Connection Manager
  const connectScale = (scale) => {
    disconnectScale();
    setSelectedScale(scale);

    if (scale.is_simulator) {
      // Connect to Simulator (polled via Flask REST client)
      setConnected(true);
      addLog(`Simulator connection established: ${scale.name}`);
      simulatorIntervalRef.current = setInterval(async () => {
        try {
          const res = await fetch(`https://soylubaharat.kobiyz.site/api/scales/${scale.id}/weight`);
          const data = await res.json();
          if (data.success) {
            setWeight(parseFloat(data.weight) || 0.0);
          }
        } catch (e) {
          console.warn('Simulator polling error:', e);
        }
      }, 300);
    } else {
      // Connect to Physical TCP Scale
      setConnected(false);
      setWeight(0.0);
      addLog(`Connecting physical scale ${scale.name} at ${scale.ip}:${scale.port}`);

      try {
        const client = TcpSocket.createConnection(
          {
            host: scale.ip,
            port: parseInt(scale.port, 10),
            reuseAddress: true,
          },
          () => {
            try {
              client.setNoDelay(true);
            } catch (e) {
              console.warn('Failed to set tcpNoDelay:', e);
            }
            addLog('TCP Socket connected successfully!');
            setConnected(true);
          }
        );

        socketRef.current = client;
        let buffer = '';

        client.on('data', (data) => {
          let chunk = '';
          if (typeof data === 'string') {
            chunk = data;
          } else if (
            data &&
            (data.constructor.name === 'Uint8Array' ||
              data.constructor.name === 'Buffer' ||
              Array.isArray(data) ||
              typeof data.forEach === 'function')
          ) {
            for (let i = 0; i < data.length; i++) {
              chunk += String.fromCharCode(data[i]);
            }
          } else {
            chunk = String(data);
          }

          buffer += chunk;
          const normalized = buffer.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
          const lines = normalized.split('\n');

          if (lines.length > 1) {
            buffer = lines[lines.length - 1];
            let latestCompleteLine = '';
            for (let i = lines.length - 2; i >= 0; i--) {
              const l = lines[i].trim();
              if (l) {
                latestCompleteLine = l;
                break;
              }
            }

            if (latestCompleteLine) {
              const match = /([+\-]?\s*\d+[\.,]?\d*)\s*(?:k?g|gr?)/i.exec(latestCompleteLine);
              if (match) {
                const weightStr = match[1].replace(/\s+/g, '').replace(',', '.');
                let weightVal = parseFloat(weightStr);
                if (!isNaN(weightVal)) {
                  const lowerLine = latestCompleteLine.toLowerCase();
                  if (lowerLine.includes('kg')) {
                    weightVal = weightVal * 1000.0;
                  }
                  setWeight(weightVal);
                }
              }
            }
          }
        });

        client.on('error', (err) => {
          addLog(`Socket connection error: ${err.message}`);
          setConnected(false);
          setWeight(0.0);
        });

        client.on('close', () => {
          addLog('Socket connection closed.');
          setConnected(false);
          setWeight(0.0);
        });
      } catch (err) {
        addLog(`Connection failed: ${err.message}`);
        setConnected(false);
        setWeight(0.0);
      }
    }
  };

  const disconnectScale = () => {
    if (socketRef.current) {
      try {
        socketRef.current.destroy();
      } catch (e) {}
      socketRef.current = null;
    }
    if (simulatorIntervalRef.current) {
      clearInterval(simulatorIntervalRef.current);
      simulatorIntervalRef.current = null;
    }
    setSelectedScale(null);
    setConnected(false);
    setWeight(0.0);
  };

  // Auth Operations
  const handleLogin = async () => {
    if (!usernameInput || !passwordInput) {
      Alert.alert('Hata', 'Kullanıcı adı ve şifre giriniz.');
      return;
    }
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await api.login(usernameInput, passwordInput, roleInput);
      if (res.success) {
        setUser({ name: usernameInput, role: roleInput });
        setUsernameInput('');
        setPasswordInput('');
        if (roleInput === 'manager') {
          setScreen('admin');
        } else {
          setScreen('station-select');
        }
      } else {
        setErrorMsg(res.message || 'Giriş başarısız.');
      }
    } catch (err) {
      setErrorMsg(err.message || 'Sunucu bağlantı hatası.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await api.logout();
    } catch (e) {}
    disconnectScale();
    setUser(null);
    setActiveJob(null);
    setScreen('login');
  };

  // Operator Actions
  const handleStartJob = async (orderId, batchId) => {
    setLoading(true);
    try {
      const res = await api.startBatch(batchId, user.name);
      if (res.success) {
        await fetchDb();
        const order = db.orders.find((o) => o.id === orderId);
        const batch = order.batches.find((b) => b.id === batchId);
        setActiveJob({ order, batch });
        setScreen('checklist');
      }
    } catch (e) {
      Alert.alert('Hata', e.message || 'Parti başlatılamadı.');
    } finally {
      setLoading(false);
    }
  };

  const handleJoinJob = (orderId, batchId) => {
    const order = db.orders.find((o) => o.id === orderId);
    const batch = order.batches.find((b) => b.id === batchId);
    if (order && batch) {
      setActiveJob({ order, batch });
      if (batch.status === 'paketlemede') {
        setScreen('packaging');
      } else {
        setScreen('checklist');
      }
    }
  };

  const handleApproveIngredient = async (itemName, targetAmount, actualAmount = null) => {
    if (actualAmount === null) actualAmount = targetAmount;
    setLoading(true);
    const logData = {
      batchId: activeJob.batch.id,
      operator: user.name,
      customer: activeJob.order.customer,
      recipe: activeJob.order.recipeName,
      item: itemName,
      target: parseFloat(targetAmount).toFixed(2),
      actual: parseFloat(actualAmount).toFixed(2),
      status: 'Başarılı',
    };

    try {
      const res = await api.addWeighingLog(logData);
      if (res.success) {
        await fetchDb();
        // Check if all items are now approved
        const activeBatchLogs = db.logs.filter((l) => l.batchId === activeJob.batch.id && l.status === 'Başarılı');
        const allApproved = activeJob.order.recipeItems.every((item) =>
          activeBatchLogs.some((l) => l.item === item.name)
        );

        if (allApproved) {
          await api.updateBatchStatus(activeJob.batch.id, 'mikserde');
          await fetchDb();
        }
        setActiveWeighingItem(null);
      }
    } catch (err) {
      Alert.alert('Hata', err.message || 'Malzeme onaylanamadı.');
    } finally {
      setLoading(false);
    }
  };

  const handleFinishPackaging = async () => {
    setLoading(true);
    try {
      const res = await api.finishBatch(activeJob.batch.id);
      if (res.success) {
        Alert.alert('Başarılı', 'Üretim tamamlandı! Fiş/etiket hazır.');
        await fetchDb();
        setActiveJob(null);
        setScreen('job-queue');
      }
    } catch (err) {
      Alert.alert('Hata', err.message || 'Parti kapatılamadı.');
    } finally {
      setLoading(false);
    }
  };

  // Admin Actions
  const handleAddScale = async () => {
    if (!newScaleName || (!newScaleIsSim && !newScaleIp)) {
      Alert.alert('Hata', 'Lütfen tüm alanları doldurun.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.addScale({
        name: newScaleName,
        ip: newScaleIsSim ? '127.0.0.1' : newScaleIp,
        port: parseInt(newScalePort, 10),
        is_simulator: newScaleIsSim,
      });
      if (res.success) {
        Alert.alert('Başarılı', 'Terazi eklendi.');
        setNewScaleName('');
        setNewScaleIp('');
        setNewScalePort('8899');
        await fetchDb();
      }
    } catch (err) {
      Alert.alert('Hata', err.message || 'Cihaz eklenemedi.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteScale = async (id) => {
    Alert.alert('Silme Onayı', 'Cihazı silmek istediğinize emin misiniz?', [
      { text: 'İptal', style: 'cancel' },
      {
        text: 'Sil',
        style: 'destructive',
        onPress: async () => {
          setLoading(true);
          try {
            await api.deleteScale(id);
            await fetchDb();
          } catch (e) {
            Alert.alert('Hata', e.message);
          } finally {
            setLoading(false);
          }
        },
      },
    ]);
  };

  const handleAddFirm = async () => {
    if (!newFirmName) return;
    setLoading(true);
    try {
      const res = await api.addFirm(newFirmName);
      if (res.success) {
        setNewFirmName('');
        await fetchDb();
      }
    } catch (e) {
      Alert.alert('Hata', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddRecipe = async () => {
    if (!newRecipeName || !newRecipeFirmId) {
      Alert.alert('Hata', 'Lütfen firma ve reçete adı seçin.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.addRecipe(newRecipeFirmId, newRecipeName);
      if (res.success) {
        setNewRecipeName('');
        await fetchDb();
      }
    } catch (e) {
      Alert.alert('Hata', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddIngredient = async () => {
    if (!selectedRecipe || !newIngredientName || !newIngredientAmount) {
      Alert.alert('Hata', 'Lütfen tüm alanları doldurun.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.addRecipeItem(selectedRecipe.id, {
        name: newIngredientName,
        amount: parseFloat(newIngredientAmount),
        tolerance: parseFloat(newIngredientTolerance || '0'),
      });
      if (res.success) {
        setNewIngredientName('');
        setNewIngredientAmount('');
        setNewIngredientTolerance('');
        await fetchDb();
        // Update local selection
        const updatedDb = await api.getDatabase();
        const r = updatedDb.recipes.find((x) => x.id === selectedRecipe.id);
        setSelectedRecipe(r);
      }
    } catch (e) {
      Alert.alert('Hata', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteIngredient = async (itemId) => {
    setLoading(true);
    try {
      const res = await api.deleteRecipeItem(selectedRecipe.id, itemId);
      if (res.success) {
        await fetchDb();
        const updatedDb = await api.getDatabase();
        const r = updatedDb.recipes.find((x) => x.id === selectedRecipe.id);
        setSelectedRecipe(r);
      }
    } catch (e) {
      Alert.alert('Hata', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateOrder = async () => {
    if (!newOrderFirm || !newOrderRecipe || !newOrderAmount) {
      Alert.alert('Hata', 'Lütfen tüm alanları doldurun.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.createOrder({
        customer: newOrderFirm,
        recipeName: newOrderRecipe,
        totalAmount: parseFloat(newOrderAmount),
        bagWeight: parseFloat(newOrderBagWeight || '20.0'),
      });
      if (res.success) {
        Alert.alert('Başarılı', 'İş Emri / Sipariş başarıyla oluşturuldu.');
        setNewOrderAmount('');
        await fetchDb();
      }
    } catch (e) {
      Alert.alert('Hata', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteBatch = async (batchId) => {
    Alert.alert('Silme Onayı', 'Bu üretimi silmek istiyor musunuz?', [
      { text: 'İptal', style: 'cancel' },
      {
        text: 'Sil',
        style: 'destructive',
        onPress: async () => {
          setLoading(true);
          try {
            await api.deleteBatch(batchId);
            await fetchDb();
          } catch (e) {
            Alert.alert('Hata', e.message);
          } finally {
            setLoading(false);
          }
        },
      },
    ]);
  };

  const handleAddUser = async () => {
    if (!newUserName || !newUserPassword) {
      Alert.alert('Hata', 'Personel adı ve şifre giriniz.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.addUser({
        name: newUserName,
        password: newUserPassword,
        role: newUserRole,
      });
      if (res.success) {
        setNewUserName('');
        setNewUserPassword('');
        Alert.alert('Başarılı', 'Personel başarıyla eklendi.');
        await fetchDb();
      }
    } catch (e) {
      Alert.alert('Hata', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (id) => {
    Alert.alert('Silme Onayı', 'Personeli silmek istediğinize emin misiniz?', [
      { text: 'İptal', style: 'cancel' },
      {
        text: 'Sil',
        style: 'destructive',
        onPress: async () => {
          setLoading(true);
          try {
            await api.deleteUser(id);
            await fetchDb();
          } catch (e) {
            Alert.alert('Hata', e.message);
          } finally {
            setLoading(false);
          }
        },
      },
    ]);
  };

  // --- RENDERING SCREENS ---

  // LOGIN SCREEN
  const renderLogin = () => (
    <View style={styles.loginContainer}>
      <View style={styles.loginCard}>
        <Text style={styles.loginTitle}>SOYLU BAHARAT</Text>
        <Text style={styles.loginSubtitle}>Endüstriyel Tartım Otomasyon Sistemi</Text>

        {errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Kullanıcı Adı</Text>
          <TextInput
            style={styles.input}
            value={usernameInput}
            onChangeText={setUsernameInput}
            placeholder="Personel Adı"
            placeholderTextColor="#64748b"
            autoCapitalize="none"
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Parola / Şifre</Text>
          <TextInput
            style={styles.input}
            value={passwordInput}
            onChangeText={setPasswordInput}
            placeholder="Parola"
            placeholderTextColor="#64748b"
            secureTextEntry
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Yetki Rolü</Text>
          <View style={styles.roleRow}>
            {['operator', 'secretary', 'manager'].map((r) => (
              <TouchableOpacity
                key={r}
                style={[styles.roleButton, roleInput === r && styles.roleButtonActive]}
                onPress={() => setRoleInput(r)}
              >
                <Text style={[styles.roleButtonText, roleInput === r && styles.roleButtonTextActive]}>
                  {r === 'operator' ? 'Operatör' : r === 'secretary' ? 'Sekreter' : 'Yönetici'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <TouchableOpacity style={styles.buttonPrimary} onPress={handleLogin} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Giriş Yap</Text>}
        </TouchableOpacity>
      </View>
    </View>
  );

  // STATION SELECT SCREEN
  const renderStationSelect = () => (
    <View style={styles.screenContainer}>
      <View style={styles.navbar}>
        <Text style={styles.navTitle}>Cihaz İstasyonu Seçin</Text>
        <TouchableOpacity style={styles.buttonDangerSmall} onPress={handleLogout}>
          <Text style={styles.buttonTextSmall}>Çıkış Yap</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.contentContainer}>
        <Text style={styles.sectionHeader}>Kayıtlı Akıllı Teraziler</Text>
        {db.scales.length === 0 ? (
          <Text style={styles.emptyText}>Kayıtlı terazi istasyonu bulunamadı.</Text>
        ) : (
          db.scales.map((s) => (
            <TouchableOpacity
              key={s.id}
              style={[
                styles.scaleCard,
                selectedScale?.id === s.id && styles.scaleCardActive,
              ]}
              onPress={() => connectScale(s)}
            >
              <View>
                <Text style={styles.scaleCardName}>
                  {s.name}{' '}
                  <Text style={s.is_simulator ? styles.simBadge : styles.physBadge}>
                    {s.is_simulator ? ' [SİMÜLASYON] ' : ' [FİZİKSEL] '}
                  </Text>
                </Text>
                <Text style={styles.scaleCardDetails}>
                  IP: {s.ip} | Port: {s.port}
                </Text>
              </View>
              <Text style={styles.scaleCardSelectText}>
                {selectedScale?.id === s.id ? 'Seçildi (Bağlı)' : 'İstasyona Bağlan'}
              </Text>
            </TouchableOpacity>
          ))
        )}

        {selectedScale && (
          <TouchableOpacity
            style={styles.buttonPrimary}
            onPress={() => setScreen('job-queue')}
            style={[styles.buttonPrimary, { marginTop: 24 }]}
          >
            <Text style={styles.buttonText}>Üretim İş Emirlerine Geç</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );

  // JOB QUEUE SCREEN
  const renderJobQueue = () => {
    // Collect all batches in pending, in-progress or mixed states
    const activeBatches = [];
    db.orders.forEach((order) => {
      order.batches.forEach((batch) => {
        if (batch.status !== 'tamamlandı') {
          activeBatches.push({ order, batch });
        }
      });
    });

    return (
      <View style={styles.screenContainer}>
        <View style={styles.navbar}>
          <View>
            <Text style={styles.navTitle}>Aktif İş Emirleri</Text>
            {selectedScale && (
              <Text style={styles.navSubTitle}>Bağlı Terazi: {selectedScale.name}</Text>
            )}
          </View>
          <View style={styles.navButtonsRow}>
            {user.role === 'manager' && (
              <TouchableOpacity
                style={[styles.buttonPrimarySmall, { marginRight: 8 }]}
                onPress={() => setScreen('admin')}
              >
                <Text style={styles.buttonTextSmall}>Yönetim Paneli</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity style={styles.buttonDangerSmall} onPress={handleLogout}>
              <Text style={styles.buttonTextSmall}>Çıkış</Text>
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView style={styles.contentContainer}>
          <Text style={styles.sectionHeader}>Tartım Sırasındaki Partiler</Text>
          {activeBatches.length === 0 ? (
            <Text style={styles.emptyText}>Bekleyen veya devam eden iş emri bulunamadı.</Text>
          ) : (
            activeBatches.map(({ order, batch }) => (
              <View key={batch.id} style={styles.jobCard}>
                <View style={styles.jobCardHeader}>
                  <View>
                    <Text style={styles.jobCardClient}>{order.customer}</Text>
                    <Text style={styles.jobCardRecipe}>{order.recipeName}</Text>
                  </View>
                  <View style={styles.statusBadgeContainer}>
                    <Text style={[styles.statusBadge, styles[`statusBadge_${batch.status}`]]}>
                      {batch.status.toUpperCase()}
                    </Text>
                  </View>
                </View>

                <View style={styles.jobCardBody}>
                  <Text style={styles.jobCardInfo}>
                    Parti No: {batch.no} / {batch.totalBatches}
                  </Text>
                  <Text style={styles.jobCardInfo}>Miktar: {batch.targetAmount} kg</Text>
                  {batch.operator && <Text style={styles.jobCardInfo}>Operatör: {batch.operator}</Text>}
                </View>

                <View style={styles.jobCardActions}>
                  {batch.status === 'beklemede' ? (
                    <TouchableOpacity
                      style={styles.buttonPrimarySmall}
                      onPress={() => handleStartJob(order.id, batch.id)}
                    >
                      <Text style={styles.buttonTextSmall}>Başlat ve Tartıma Gir</Text>
                    </TouchableOpacity>
                  ) : (
                    <TouchableOpacity
                      style={styles.buttonSuccessSmall}
                      onPress={() => handleJoinJob(order.id, batch.id)}
                    >
                      <Text style={styles.buttonTextSmall}>Devam Et / Katıl</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            ))
          )}
        </ScrollView>
      </View>
    );
  };

  // ACTIVE CHECKLIST SCREEN
  const renderChecklist = () => {
    if (!activeJob) return null;
    const { order, batch } = activeJob;

    const scaleFactor = batch.targetAmount;
    const activeBatchLogs = db.logs.filter((l) => l.batchId === batch.id && l.status === 'Başarılı');

    const allApproved = order.recipeItems.every((item) =>
      activeBatchLogs.some((l) => l.item === item.name)
    );

    return (
      <View style={styles.screenContainer}>
        {/* Connection Header Panel */}
        <View style={styles.headerPanel}>
          <View style={styles.headerLeft}>
            <Text style={styles.panelTitle}>AKTİF TARTI DEĞERİ</Text>
            <Text style={[styles.largeWeightText, connected ? styles.weightOnline : styles.weightOffline]}>
              {weight.toFixed(1)} <Text style={styles.weightUnitText}>gr</Text>
            </Text>
          </View>
          <View style={styles.headerRight}>
            <View style={[styles.statusIndicator, connected ? styles.indicatorOnline : styles.indicatorOffline]}>
              <View style={[styles.statusDot, connected ? styles.dotOnline : styles.dotOffline]} />
              <Text style={styles.statusLabel}>{connected ? 'BAĞLI' : 'BAĞLANTI YOK'}</Text>
            </View>
            {selectedScale && (
              <Text style={styles.connectionDetails}>{selectedScale.ip}:{selectedScale.port}</Text>
            )}
          </View>
        </View>

        <View style={styles.checklistDetailsBar}>
          <View>
            <Text style={styles.detailsTextLabel}>Müşteri: <Text style={styles.detailsTextValue}>{order.customer}</Text></Text>
            <Text style={styles.detailsTextLabel}>Reçete: <Text style={styles.detailsTextValue}>{order.recipeName}</Text></Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.detailsTextLabel}>Parti: <Text style={styles.detailsTextValue}>{batch.no} ({batch.targetAmount} kg)</Text></Text>
            <Text style={styles.detailsTextLabel}>Usta: <Text style={styles.detailsTextValue}>{user.name}</Text></Text>
          </View>
        </View>

        <ScrollView style={styles.contentContainer}>
          <Text style={styles.sectionHeader}>Reçete Malzeme Listesi</Text>

          {order.recipeItems.map((item) => {
            const targetAmount = item.amount * scaleFactor;
            const logEntry = activeBatchLogs.find((l) => l.item === item.name);
            const isApproved = !!logEntry;
            const isActive = activeWeighingItem?.name === item.name;

            if (isApproved) {
              return (
                <View key={item.name} style={[styles.checklistCard, styles.checklistCardApproved]}>
                  <View>
                    <Text style={styles.checklistCardName}>{item.name}</Text>
                    <Text style={styles.checklistCardValue}>Onaylandı: {logEntry.actual} gr</Text>
                  </View>
                  <Text style={styles.approvedBadgeText}>✓ ONAYLANDI ({logEntry.operator})</Text>
                </View>
              );
            }

            if (isActive) {
              const target = activeWeighingItem.targetAmount;
              const tol = activeWeighingItem.tolerance;
              const matchesTolerance = weight >= target - tol && weight <= target + tol;

              return (
                <View key={item.name} style={[styles.checklistCard, styles.checklistCardActive]}>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.checklistCardName, { color: '#f43f5e' }]}>● {item.name}</Text>
                    <Text style={styles.checklistCardLiveValue}>TARTI: {weight.toFixed(2)} gr</Text>
                    <Text style={styles.checklistCardTargetValue}>Hedef: {target.toFixed(2)} gr (±{tol.toFixed(2)} gr)</Text>
                  </View>
                  <View>
                    <TouchableOpacity
                      style={matchesTolerance ? styles.buttonSuccessSmall : styles.buttonDisabledSmall}
                      disabled={!matchesTolerance}
                      onPress={() => handleApproveIngredient(item.name, target, weight)}
                    >
                      <Text style={styles.buttonTextSmall}>Onayla</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.buttonDangerSmall, { marginTop: 8 }]}
                      onPress={() => setActiveWeighingItem(null)}
                    >
                      <Text style={styles.buttonTextSmall}>İptal</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              );
            }

            return (
              <View key={item.name} style={styles.checklistCard}>
                <View>
                  <Text style={styles.checklistCardName}>{item.name}</Text>
                  <Text style={styles.checklistCardTargetValue}>Hedef: {targetAmount.toFixed(2)} gr</Text>
                </View>
                {connected ? (
                  <TouchableOpacity
                    style={styles.buttonPrimarySmall}
                    onPress={() =>
                      setActiveWeighingItem({
                        name: item.name,
                        targetAmount,
                        tolerance: item.tolerance * scaleFactor,
                      })
                    }
                  >
                    <Text style={styles.buttonTextSmall}>Tartıma Başla</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    style={styles.buttonSuccessSmall}
                    onPress={() => handleApproveIngredient(item.name, targetAmount)}
                  >
                    <Text style={styles.buttonTextSmall}>Manuel Onayla</Text>
                  </TouchableOpacity>
                )}
              </View>
            );
          })}

          {allApproved && (
            <View style={styles.completionContainer}>
              <Text style={styles.completionHeader}>TARTIMLAR TAMAMLANDI!</Text>
              <Text style={styles.completionSub}>Girdiler onaylandı. Paketleme ekranına geçin.</Text>
              <TouchableOpacity
                style={styles.buttonSuccess}
                onPress={async () => {
                  try {
                    await api.updateBatchStatus(batch.id, 'paketlemede');
                    await fetchDb();
                    setScreen('packaging');
                  } catch (e) {
                    Alert.alert('Hata', 'Durum güncellenemedi.');
                  }
                }}
              >
                <Text style={styles.buttonText}>Paketleme Aşamasına Geç</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      </View>
    );
  };

  // PACKAGING SCREEN
  const renderPackaging = () => {
    if (!activeJob) return null;
    const { batch } = activeJob;

    const batchWeight = batch.targetAmount;
    const bagWeight = batch.bagWeight || 20.0;
    const fullBags = Math.floor(batchWeight / bagWeight);
    const remainder = batchWeight - fullBags * bagWeight;
    const totalBags = fullBags + (remainder > 0.01 ? 1 : 0);

    return (
      <View style={styles.screenContainer}>
        <View style={styles.navbar}>
          <Text style={styles.navTitle}>Mikserleme & Paketleme</Text>
          <TouchableOpacity
            style={styles.buttonPrimarySmall}
            onPress={() => {
              setActiveJob(null);
              setScreen('job-queue');
            }}
          >
            <Text style={styles.buttonTextSmall}>Geri Dön</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.contentContainer}>
          <View style={styles.packagingCard}>
            <Text style={styles.packagingHeader}>Torbalama / Paketleme Raporu</Text>
            <Text style={styles.packagingSummary}>Toplam Ağırlık: {batchWeight.toFixed(2)} kg</Text>
            <Text style={styles.packagingSummary}>Torba Toleransı: {bagWeight.toFixed(2)} kg</Text>

            <View style={styles.divider} />

            <Text style={styles.packagingListTitle}>Hazırlanacak Torba Dağılımı ({totalBags} Adet):</Text>
            {fullBags > 0 && (
              <Text style={styles.packagingItem}>• {fullBags} adet x {bagWeight.toFixed(2)} kg torba</Text>
            )}
            {remainder > 0.01 && (
              <Text style={styles.packagingItem}>• 1 adet x {remainder.toFixed(2)} kg torba (Kalan Kısım)</Text>
            )}

            <TouchableOpacity style={[styles.buttonSuccess, { marginTop: 32 }]} onPress={handleFinishPackaging}>
              <Text style={styles.buttonText}>Paketlemeyi Bitir / Tamamla</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    );
  };

  // ADMIN SCREEN
  const renderAdmin = () => (
    <View style={styles.screenContainer}>
      <View style={styles.navbar}>
        <Text style={styles.navTitle}>Yönetici Paneli</Text>
        <View style={styles.navButtonsRow}>
          <TouchableOpacity
            style={[styles.buttonPrimarySmall, { marginRight: 8 }]}
            onPress={() => setScreen('job-queue')}
          >
            <Text style={styles.buttonTextSmall}>Tartım Ekranı</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.buttonDangerSmall} onPress={handleLogout}>
            <Text style={styles.buttonTextSmall}>Çıkış</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Admin Tabs */}
      <View style={styles.tabBar}>
        {[
          { key: 'scales', label: 'Cihazlar' },
          { key: 'firms', label: 'Firmalar' },
          { key: 'recipes', label: 'Reçeteler' },
          { key: 'orders', label: 'Siparişler' },
          { key: 'users', label: 'Personel' },
        ].map((t) => (
          <TouchableOpacity
            key={t.key}
            style={[styles.tabItem, adminTab === t.key && styles.tabItemActive]}
            onPress={() => setAdminTab(t.key)}
          >
            <Text style={[styles.tabItemText, adminTab === t.key && styles.tabItemTextActive]}>
              {t.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.contentContainer}>
        {/* SCALES TAB */}
        {adminTab === 'scales' && (
          <View>
            <Text style={styles.sectionHeader}>Akıllı Terazi Ekle</Text>
            <TextInput
              style={styles.input}
              value={newScaleName}
              onChangeText={setNewScaleName}
              placeholder="Terazi Adı (Örn: Deneme)"
              placeholderTextColor="#64748b"
            />
            <TextInput
              style={styles.input}
              value={newScaleIp}
              onChangeText={setNewScaleIp}
              placeholder="IP Adresi (Örn: 192.168.1.101)"
              placeholderTextColor="#64748b"
              keyboardType="numeric"
              disabled={newScaleIsSim}
            />
            <TextInput
              style={styles.input}
              value={newScalePort}
              onChangeText={setNewScalePort}
              placeholder="Port (Örn: 8899)"
              placeholderTextColor="#64748b"
              keyboardType="numeric"
            />
            <TouchableOpacity
              style={styles.checkboxRow}
              onPress={() => setNewScaleIsSim(!newScaleIsSim)}
            >
              <View style={[styles.checkbox, newScaleIsSim && styles.checkboxChecked]} />
              <Text style={styles.checkboxLabel}>Simülasyon Cihazı Olarak Ekle</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.buttonPrimary} onPress={handleAddScale}>
              <Text style={styles.buttonText}>Cihazı Kaydet</Text>
            </TouchableOpacity>

            <Text style={[styles.sectionHeader, { marginTop: 24 }]}>Kayıtlı Cihazlar</Text>
            {db.scales.map((s) => (
              <View key={s.id} style={styles.adminListCard}>
                <View>
                  <Text style={styles.adminListCardTitle}>
                    {s.name} {s.is_simulator ? '[SIM]' : ''}
                  </Text>
                  <Text style={styles.adminListCardSub}>
                    {s.ip}:{s.port}
                  </Text>
                </View>
                <TouchableOpacity style={styles.buttonDangerSmall} onPress={() => handleDeleteScale(s.id)}>
                  <Text style={styles.buttonTextSmall}>Sil</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        )}

        {/* FIRMS TAB */}
        {adminTab === 'firms' && (
          <View>
            <Text style={styles.sectionHeader}>Yeni Firma Ekle</Text>
            <TextInput
              style={styles.input}
              value={newFirmName}
              onChangeText={setNewFirmName}
              placeholder="Firma / Müşteri Adı"
              placeholderTextColor="#64748b"
            />
            <TouchableOpacity style={styles.buttonPrimary} onPress={handleAddFirm}>
              <Text style={styles.buttonText}>Firmayı Kaydet</Text>
            </TouchableOpacity>

            <Text style={[styles.sectionHeader, { marginTop: 24 }]}>Firmalar</Text>
            {db.firms.map((f) => (
              <View key={f.id} style={styles.adminListCard}>
                <Text style={styles.adminListCardTitle}>{f.name}</Text>
              </View>
            ))}
          </View>
        )}

        {/* RECIPES TAB */}
        {adminTab === 'recipes' && (
          <View>
            <Text style={styles.sectionHeader}>Yeni Reçete Ekle</Text>
            <TextInput
              style={styles.input}
              value={newRecipeName}
              onChangeText={setNewRecipeName}
              placeholder="Reçete Adı"
              placeholderTextColor="#64748b"
            />
            <Text style={styles.label}>İlişkili Firma</Text>
            <ScrollView horizontal style={styles.horizontalScroll}>
              {db.firms.map((f) => (
                <TouchableOpacity
                  key={f.id}
                  style={[styles.smallBadgeBtn, newRecipeFirmId === String(f.id) && styles.smallBadgeBtnActive]}
                  onPress={() => setNewRecipeFirmId(String(f.id))}
                >
                  <Text style={[styles.smallBadgeBtnText, newRecipeFirmId === String(f.id) && styles.smallBadgeBtnTextActive]}>
                    {f.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TouchableOpacity style={styles.buttonPrimary} onPress={handleAddRecipe}>
              <Text style={styles.buttonText}>Reçeteyi Oluştur</Text>
            </TouchableOpacity>

            <Text style={[styles.sectionHeader, { marginTop: 24 }]}>Reçeteler & İçerik Detayları</Text>
            {db.recipes.map((r) => (
              <TouchableOpacity
                key={r.id}
                style={[styles.adminListCard, selectedRecipe?.id === r.id && styles.adminListCardActive]}
                onPress={() => setSelectedRecipe(r)}
              >
                <Text style={styles.adminListCardTitle}>{r.name}</Text>
                <Text style={styles.adminListCardSub}>Firma ID: {r.firm_id}</Text>
              </TouchableOpacity>
            ))}

            {selectedRecipe && (
              <View style={styles.ingredientPanel}>
                <Text style={styles.ingredientPanelTitle}>{selectedRecipe.name} Reçete Malzemeleri</Text>
                {selectedRecipe.items?.map((item) => (
                  <View key={item.id} style={styles.ingredientRow}>
                    <Text style={styles.ingredientText}>
                      • {item.name}: {item.amount} gr (±{item.tolerance} gr)
                    </Text>
                    <TouchableOpacity
                      style={styles.buttonDangerSmall}
                      onPress={() => handleDeleteIngredient(item.id)}
                    >
                      <Text style={styles.buttonTextSmall}>Sil</Text>
                    </TouchableOpacity>
                  </View>
                ))}

                <Text style={[styles.sectionHeader, { marginTop: 16 }]}>Malzeme Ekle</Text>
                <TextInput
                  style={styles.input}
                  value={newIngredientName}
                  onChangeText={setNewIngredientName}
                  placeholder="Malzeme Adı (Örn: Karabiber)"
                  placeholderTextColor="#64748b"
                />
                <TextInput
                  style={styles.input}
                  value={newIngredientAmount}
                  onChangeText={setNewIngredientAmount}
                  placeholder="Miktar (Gram)"
                  placeholderTextColor="#64748b"
                  keyboardType="numeric"
                />
                <TextInput
                  style={styles.input}
                  value={newIngredientTolerance}
                  onChangeText={setNewIngredientTolerance}
                  placeholder="Tolerans Payı (Gram)"
                  placeholderTextColor="#64748b"
                  keyboardType="numeric"
                />
                <TouchableOpacity style={styles.buttonPrimary} onPress={handleAddIngredient}>
                  <Text style={styles.buttonText}>Malzemeyi Kaydet</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}

        {/* ORDERS TAB */}
        {adminTab === 'orders' && (
          <View>
            <Text style={styles.sectionHeader}>İş Emri / Üretim Siparişi Oluştur</Text>
            <Text style={styles.label}>Müşteri Firma</Text>
            <ScrollView horizontal style={styles.horizontalScroll}>
              {db.firms.map((f) => (
                <TouchableOpacity
                  key={f.id}
                  style={[styles.smallBadgeBtn, newOrderFirm === f.name && styles.smallBadgeBtnActive]}
                  onPress={() => setNewOrderFirm(f.name)}
                >
                  <Text style={[styles.smallBadgeBtnText, newOrderFirm === f.name && styles.smallBadgeBtnTextActive]}>
                    {f.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <Text style={styles.label}>Seçilecek Reçete</Text>
            <ScrollView horizontal style={styles.horizontalScroll}>
              {db.recipes.map((r) => (
                <TouchableOpacity
                  key={r.id}
                  style={[styles.smallBadgeBtn, newOrderRecipe === r.name && styles.smallBadgeBtnActive]}
                  onPress={() => setNewOrderRecipe(r.name)}
                >
                  <Text style={[styles.smallBadgeBtnText, newOrderRecipe === r.name && styles.smallBadgeBtnTextActive]}>
                    {r.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <TextInput
              style={styles.input}
              value={newOrderAmount}
              onChangeText={setNewOrderAmount}
              placeholder="Toplam Sipariş Miktarı (KG)"
              placeholderTextColor="#64748b"
              keyboardType="numeric"
            />
            <TextInput
              style={styles.input}
              value={newOrderBagWeight}
              onChangeText={setNewOrderBagWeight}
              placeholder="Torba Tolerans Ağırlığı (Örn: 20)"
              placeholderTextColor="#64748b"
              keyboardType="numeric"
            />

            <TouchableOpacity style={styles.buttonPrimary} onPress={handleCreateOrder}>
              <Text style={styles.buttonText}>Siparişi Başlat</Text>
            </TouchableOpacity>

            <Text style={[styles.sectionHeader, { marginTop: 24 }]}>Aktif Sipariş & Partiler</Text>
            {db.orders.map((o) => (
              <View key={o.id} style={styles.adminOrderCard}>
                <Text style={styles.adminOrderCustomer}>{o.customer}</Text>
                <Text style={styles.adminOrderRecipe}>{o.recipeName} ({o.totalAmount} kg)</Text>
                {o.batches.map((b) => (
                  <View key={b.id} style={styles.adminBatchRow}>
                    <Text style={styles.adminBatchRowText}>
                      Parti {b.no}: {b.targetAmount} kg ({b.status})
                    </Text>
                    {b.status !== 'tamamlandı' && (
                      <TouchableOpacity
                        style={styles.buttonDangerSmall}
                        onPress={() => handleDeleteBatch(b.id)}
                      >
                        <Text style={styles.buttonTextSmall}>Sil</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                ))}
              </View>
            ))}
          </View>
        )}

        {/* USERS TAB */}
        {adminTab === 'users' && (
          <View>
            <Text style={styles.sectionHeader}>Yeni Personel Tanımla</Text>
            <TextInput
              style={styles.input}
              value={newUserName}
              onChangeText={setNewUserName}
              placeholder="Kullanıcı / Personel Adı"
              placeholderTextColor="#64748b"
              autoCapitalize="none"
            />
            <TextInput
              style={styles.input}
              value={newUserPassword}
              onChangeText={setNewUserPassword}
              placeholder="Giriş Şifresi"
              placeholderTextColor="#64748b"
              secureTextEntry
            />
            <Text style={styles.label}>Rolü</Text>
            <View style={styles.roleRow}>
              {['operator', 'secretary', 'manager'].map((r) => (
                <TouchableOpacity
                  key={r}
                  style={[styles.roleButton, newUserRole === r && styles.roleButtonActive]}
                  onPress={() => setNewUserRole(r)}
                >
                  <Text style={[styles.roleButtonText, newUserRole === r && styles.roleButtonTextActive]}>
                    {r === 'operator' ? 'Operatör' : r === 'secretary' ? 'Sekreter' : 'Yönetici'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity style={styles.buttonPrimary} onPress={handleAddUser}>
              <Text style={styles.buttonText}>Personeli Ekle</Text>
            </TouchableOpacity>

            <Text style={[styles.sectionHeader, { marginTop: 24 }]}>Kayıtlı Personeller</Text>
            {db.users.map((u) => (
              <View key={u.id} style={styles.adminListCard}>
                <View>
                  <Text style={styles.adminListCardTitle}>{u.name}</Text>
                  <Text style={styles.adminListCardSub}>Rolü: {u.role}</Text>
                </View>
                <TouchableOpacity style={styles.buttonDangerSmall} onPress={() => handleDeleteUser(u.id)}>
                  <Text style={styles.buttonTextSmall}>Kaldır</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {screen === 'login' && renderLogin()}
      {screen === 'station-select' && renderStationSelect()}
      {screen === 'job-queue' && renderJobQueue()}
      {screen === 'checklist' && renderChecklist()}
      {screen === 'packaging' && renderPackaging()}
      {screen === 'admin' && renderAdmin()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617',
  },
  screenContainer: {
    flex: 1,
  },
  contentContainer: {
    flex: 1,
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  navbar: {
    backgroundColor: '#0f172a',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 2,
    borderBottomColor: '#1e293b',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  navTitle: {
    color: '#f8fafc',
    fontSize: 18,
    fontWeight: '800',
  },
  navSubTitle: {
    color: '#94a3b8',
    fontSize: 12,
    marginTop: 2,
  },
  navButtonsRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  // LOGIN SCREEN STYLES
  loginContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  loginCard: {
    backgroundColor: '#0f172a',
    width: '100%',
    maxWidth: 420,
    borderRadius: 24,
    padding: 30,
    borderWidth: 1,
    borderColor: '#1e293b',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 8,
  },
  loginTitle: {
    color: '#f97316',
    fontSize: 32,
    fontWeight: '900',
    textAlign: 'center',
    letterSpacing: 2,
  },
  loginSubtitle: {
    color: '#64748b',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 24,
  },
  inputGroup: {
    marginBottom: 18,
  },
  label: {
    color: '#cbd5e1',
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 12,
    color: '#f8fafc',
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 14,
    marginBottom: 10,
  },
  roleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  roleButton: {
    flex: 1,
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 12,
    paddingVertical: 10,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  roleButtonActive: {
    borderColor: '#f97316',
    backgroundColor: 'rgba(249, 115, 22, 0.1)',
  },
  roleButtonText: {
    color: '#64748b',
    fontSize: 12,
    fontWeight: 'bold',
  },
  roleButtonTextActive: {
    color: '#f97316',
  },
  buttonPrimary: {
    backgroundColor: '#f97316',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#f97316',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 4,
    marginTop: 10,
  },
  buttonPrimarySmall: {
    backgroundColor: '#f97316',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonSuccessSmall: {
    backgroundColor: '#10b981',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonDisabledSmall: {
    backgroundColor: '#334155',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 0.5,
  },
  buttonSuccess: {
    backgroundColor: '#10b981',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonDangerSmall: {
    backgroundColor: '#ef4444',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  buttonTextSmall: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  errorText: {
    color: '#ef4444',
    fontSize: 13,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  sectionHeader: {
    color: '#f8fafc',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 12,
    letterSpacing: 0.5,
  },
  emptyText: {
    color: '#64748b',
    fontSize: 13,
    fontStyle: 'italic',
    textAlign: 'center',
    paddingVertical: 20,
  },
  // SCALE CARD STYLES
  scaleCard: {
    backgroundColor: '#0f172a',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#1e293b',
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  scaleCardActive: {
    borderColor: '#f97316',
    borderWidth: 2,
    backgroundColor: '#0f172a',
  },
  scaleCardName: {
    color: '#f8fafc',
    fontSize: 16,
    fontWeight: 'bold',
  },
  scaleCardDetails: {
    color: '#64748b',
    fontSize: 12,
    marginTop: 4,
    fontFamily: 'monospace',
  },
  scaleCardSelectText: {
    color: '#f97316',
    fontWeight: 'bold',
    fontSize: 12,
  },
  simBadge: {
    color: '#38bdf8',
    fontWeight: 'bold',
    fontSize: 9,
  },
  physBadge: {
    color: '#f97316',
    fontWeight: 'bold',
    fontSize: 9,
  },
  // JOB CARD STYLES
  jobCard: {
    backgroundColor: '#0f172a',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#1e293b',
    marginBottom: 14,
  },
  jobCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
    paddingBottom: 10,
    marginBottom: 10,
  },
  jobCardClient: {
    color: '#f8fafc',
    fontSize: 16,
    fontWeight: '800',
  },
  jobCardRecipe: {
    color: '#94a3b8',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
  jobCardBody: {
    marginBottom: 12,
  },
  jobCardInfo: {
    color: '#64748b',
    fontSize: 12,
    marginTop: 3,
  },
  jobCardActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  statusBadgeContainer: {
    alignItems: 'flex-end',
  },
  statusBadge: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 6,
    fontSize: 9,
    fontWeight: 'bold',
  },
  statusBadge_beklemede: {
    backgroundColor: '#1e293b',
    color: '#94a3b8',
  },
  statusBadge_tartımda: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    color: '#ef4444',
  },
  statusBadge_mikserde: {
    backgroundColor: 'rgba(249, 115, 22, 0.1)',
    color: '#f97316',
  },
  statusBadge_paketlemede: {
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    color: '#10b981',
  },
  // WEIGHING HEADER PANEL
  headerPanel: {
    backgroundColor: '#0f172a',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 2,
    borderBottomColor: '#1e293b',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerLeft: {
    flexDirection: 'column',
  },
  panelTitle: {
    color: '#64748b',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1,
    marginBottom: 4,
  },
  largeWeightText: {
    fontSize: 40,
    fontWeight: '900',
    fontFamily: 'monospace',
  },
  weightUnitText: {
    fontSize: 18,
    color: '#64748b',
    fontWeight: '600',
  },
  weightOnline: {
    color: '#10b981',
  },
  weightOffline: {
    color: '#64748b',
  },
  headerRight: {
    alignItems: 'flex-end',
  },
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
    backgroundColor: '#1e293b',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  dotOnline: {
    backgroundColor: '#10b981',
  },
  dotOffline: {
    backgroundColor: '#ef4444',
  },
  statusLabel: {
    color: '#f8fafc',
    fontSize: 11,
    fontWeight: '600',
  },
  connectionDetails: {
    color: '#64748b',
    fontSize: 11,
    marginTop: 6,
    fontFamily: 'monospace',
  },
  checklistDetailsBar: {
    backgroundColor: '#020617',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  detailsTextLabel: {
    color: '#64748b',
    fontSize: 11,
    fontWeight: 'bold',
  },
  detailsTextValue: {
    color: '#f8fafc',
    fontWeight: 'normal',
  },
  // CHECKLIST CARD STYLES
  checklistCard: {
    backgroundColor: '#0f172a',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#1e293b',
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  checklistCardApproved: {
    borderColor: 'rgba(16, 185, 129, 0.3)',
    backgroundColor: 'rgba(16, 185, 129, 0.05)',
  },
  checklistCardActive: {
    borderColor: '#ef4444',
    borderWidth: 2,
    backgroundColor: 'rgba(239, 68, 68, 0.05)',
  },
  checklistCardName: {
    color: '#f8fafc',
    fontSize: 15,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  checklistCardTargetValue: {
    color: '#94a3b8',
    fontSize: 12,
    marginTop: 3,
    fontFamily: 'monospace',
  },
  checklistCardValue: {
    color: '#10b981',
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: 3,
    fontFamily: 'monospace',
  },
  checklistCardLiveValue: {
    color: '#f43f5e',
    fontSize: 22,
    fontWeight: '900',
    fontFamily: 'monospace',
    marginTop: 6,
  },
  checklistCardTargetValueActive: {
    color: '#94a3b8',
    fontSize: 12,
    fontFamily: 'monospace',
  },
  approvedBadgeText: {
    color: '#10b981',
    fontWeight: 'bold',
    fontSize: 11,
  },
  completionContainer: {
    backgroundColor: 'rgba(16, 185, 129, 0.05)',
    borderWidth: 1,
    borderColor: '#10b981',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    marginTop: 16,
    marginBottom: 32,
  },
  completionHeader: {
    color: '#10b981',
    fontSize: 18,
    fontWeight: '950',
    letterSpacing: 1,
  },
  completionSub: {
    color: '#cbd5e1',
    fontSize: 12,
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 20,
  },
  // PACKAGING VIEW
  packagingCard: {
    backgroundColor: '#0f172a',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: '#1e293b',
  },
  packagingHeader: {
    color: '#f97316',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 16,
  },
  packagingSummary: {
    color: '#cbd5e1',
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 4,
  },
  divider: {
    height: 1,
    backgroundColor: '#1e293b',
    marginVertical: 20,
  },
  packagingListTitle: {
    color: '#f8fafc',
    fontSize: 13,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  packagingItem: {
    color: '#94a3b8',
    fontSize: 13,
    marginTop: 6,
  },
  // ADMIN TABS & VIEW
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#0f172a',
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
  },
  tabItem: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
  },
  tabItemActive: {
    borderBottomWidth: 3,
    borderBottomColor: '#f97316',
  },
  tabItemText: {
    color: '#64748b',
    fontSize: 11,
    fontWeight: 'bold',
  },
  tabItemTextActive: {
    color: '#f97316',
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 12,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderWidth: 2,
    borderColor: '#64748b',
    borderRadius: 4,
    marginRight: 10,
  },
  checkboxChecked: {
    borderColor: '#f97316',
    backgroundColor: '#f97316',
  },
  checkboxLabel: {
    color: '#cbd5e1',
    fontSize: 13,
    fontWeight: 'bold',
  },
  adminListCard: {
    backgroundColor: '#0f172a',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: '#1e293b',
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  adminListCardActive: {
    borderColor: '#f97316',
  },
  adminListCardTitle: {
    color: '#f8fafc',
    fontSize: 14,
    fontWeight: 'bold',
  },
  adminListCardSub: {
    color: '#64748b',
    fontSize: 11,
    marginTop: 2,
  },
  horizontalScroll: {
    marginVertical: 10,
    flexDirection: 'row',
  },
  smallBadgeBtn: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginRight: 8,
  },
  smallBadgeBtnActive: {
    borderColor: '#f97316',
    backgroundColor: 'rgba(249, 115, 22, 0.1)',
  },
  smallBadgeBtnText: {
    color: '#64748b',
    fontSize: 11,
    fontWeight: 'bold',
  },
  smallBadgeBtnTextActive: {
    color: '#f97316',
  },
  ingredientPanel: {
    marginTop: 16,
    backgroundColor: '#090d16',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#1e293b',
  },
  ingredientPanelTitle: {
    color: '#f97316',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  ingredientRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
  },
  ingredientText: {
    color: '#cbd5e1',
    fontSize: 12,
  },
  adminOrderCard: {
    backgroundColor: '#0f172a',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: '#1e293b',
    marginBottom: 12,
  },
  adminOrderCustomer: {
    color: '#f8fafc',
    fontSize: 14,
    fontWeight: 'bold',
  },
  adminOrderRecipe: {
    color: '#64748b',
    fontSize: 12,
    marginTop: 2,
    marginBottom: 10,
  },
  adminBatchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
    borderTopWidth: 1,
    borderTopColor: '#1e293b',
  },
  adminBatchRowText: {
    color: '#94a3b8',
    fontSize: 11,
  },
});
