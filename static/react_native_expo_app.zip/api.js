const BASE_URL = 'https://soylubaharat.kobiyz.site';

export async function request(endpoint, options = {}) {
  const url = `${BASE_URL}${endpoint}`;
  
  // Set JSON headers by default
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    ...options.headers,
  };

  const config = {
    ...options,
    headers,
  };

  if (config.body && typeof config.body !== 'string') {
    config.body = JSON.stringify(config.body);
  }

  try {
    const response = await fetch(url, config);
    if (!response.ok) {
      const errText = await response.text();
      let errJson;
      try {
        errJson = JSON.parse(errText);
      } catch (e) {}
      throw new Error((errJson && errJson.message) || `HTTP Error ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`API Error on ${endpoint}:`, error);
    throw error;
  }
}

export const api = {
  login: (username, password, role) => request('/api/auth/login', {
    method: 'POST',
    body: { username, password, role },
  }),
  logout: () => request('/api/auth/logout', { method: 'POST' }),
  getAuthStatus: () => request('/api/auth/status'),
  getDatabase: () => request('/api/db'),
  getScales: () => request('/api/db').then(db => db.scales || []),
  startBatch: (batchId, operator) => request(`/api/batches/${batchId}/start`, {
    method: 'POST',
    body: { operator },
  }),
  finishBatch: (batchId) => request(`/api/batches/${batchId}/finish`, {
    method: 'POST',
  }),
  updateBatchStatus: (batchId, status) => request(`/api/batches/${batchId}/status`, {
    method: 'PUT',
    body: { status },
  }),
  addWeighingLog: (logData) => request('/api/logs', {
    method: 'POST',
    body: logData,
  }),
  addFirm: (name) => request('/api/firms', {
    method: 'POST',
    body: { name },
  }),
  addRecipe: (firmId, name) => request('/api/recipes', {
    method: 'POST',
    body: { firmId, name },
  }),
  addRecipeItem: (recipeId, itemData) => request(`/api/recipes/${recipeId}/items`, {
    method: 'POST',
    body: itemData, // name, amount, tolerance
  }),
  deleteRecipeItem: (recipeId, itemId) => request(`/api/recipes/${recipeId}/items/${itemId}`, {
    method: 'DELETE',
  }),
  createOrder: (orderData) => request('/api/orders', {
    method: 'POST',
    body: orderData,
  }),
  deleteBatch: (batchId) => request(`/api/batches/${batchId}`, {
    method: 'DELETE',
  }),
  addScale: (scaleData) => request('/api/scales', {
    method: 'POST',
    body: scaleData,
  }),
  deleteScale: (scaleId) => request(`/api/scales/${scaleId}`, {
    method: 'DELETE',
  }),
  addUser: (userData) => request('/api/users', {
    method: 'POST',
    body: userData,
  }),
  deleteUser: (userId) => request(`/api/users/${userId}`, {
    method: 'DELETE',
  }),
  updateUserPermissions: (userId, permissions) => request(`/api/users/${userId}/permissions`, {
    method: 'PUT',
    body: permissions,
  }),
};
