package com.soylubaharat.otomasyon

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Socket
import java.net.InetSocketAddress
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    @Volatile private var liveWeight: Double = 0.0
    @Volatile private var scaleConnected: Boolean = false
    
    private var currentSocket: Socket? = null
    private var currentThread: Thread? = null
    @Volatile private var shouldRun: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        webView = WebView(this)
        setContentView(webView)

        setupWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(ScaleInterface(), "AndroidScale")
        webView.loadUrl("http://soylubaharat.kobiyz.site")
    }

    @Synchronized
    private fun startScaleThread(ip: String, port: Int) {
        shouldRun = false
        try {
            currentSocket?.close()
        } catch (e: Exception) {}
        
        shouldRun = true
        currentThread = thread(start = true, isDaemon = true) {
            while (shouldRun) {
                try {
                    val socket = Socket()
                    currentSocket = socket
                    socket.connect(InetSocketAddress(ip, port), 4000)
                    socket.soTimeout = 4000
                    scaleConnected = true
                    
                    val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                    val regex = Regex("([+\\-]?\\s*\\d+\\.\\?\\d*)")
                    
                    reader.forEachLine { line ->
                        if (!shouldRun) return@forEachLine
                        val match = regex.find(line)
                        if (match != null) {
                            val weightStr = match.groupValues[1].replace(" ", "")
                            liveWeight = weightStr.toDoubleOrNull() ?: liveWeight
                        }
                    }
                } catch (e: Exception) {
                    scaleConnected = false
                    liveWeight = 0.0
                }
                if (shouldRun) {
                    Thread.sleep(3000)
                }
            }
        }
    }

    inner class ScaleInterface {
        @JavascriptInterface
        fun getWeight(): Double = liveWeight

        @JavascriptInterface
        fun isConnected(): Boolean = scaleConnected

        @JavascriptInterface
        fun connectToScale(ip: String, portStr: String) {
            val port = portStr.toIntOrNull() ?: 8899
            startScaleThread(ip, port)
        }

        @JavascriptInterface
        fun disconnectScale() {
            shouldRun = false
            scaleConnected = false
            liveWeight = 0.0
            try {
                currentSocket?.close()
            } catch (e: Exception) {}
        }
    }
}
