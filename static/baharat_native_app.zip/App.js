import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  View,
  Text,
  SafeAreaView,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  ActivityIndicator,
  Vibration,
  Alert,
  LogBox,
} from 'react-native';
import TcpSocket from 'react-native-tcp-socket';
import { api } from './api';

LogBox.ignoreAllLogs();

export default function App() {
  // Navigation & User State
  const [screen, setScreen] = useState('login'); // login, station-select, job-queue, checklist, packaging, admin
  const [user, setUser] = useState(null);
  const [db, setDb] = useState({ users: [], scales: [], firms: [], recipes: [], orders: [], logs: [] });
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  // Authentication Fields
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [roleInput, setRoleInput] = useState('operator'); // operator, manager, secretary

  // Scale Connection State
  const [selectedScale, setSelectedScale] = useState(null);
  const [connected, setConnected] = useState(false);
  const [weight, setWeight] = useState(0.0);
  const socketRef = useRef(null);

  // Job Queue & Active Weighing State
  const [activeBatch, setActiveBatch] = useState(null);
  const [activeOrder, setActiveOrder] = useState(null);
  const [activeRecipeItems, setActiveRecipeItems] = useState([]);
  const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const [logsForCurrentBatch, setLogsForCurrentBatch] = useState([]);

  // Admin Panel State
  const [adminTab, setAdminTab] = useState('scales'); // scales, firms, recipes, orders, users
  // Admin Form Fields
  const [scaleNameInput, setScaleNameInput] = useState('');
  const [scaleIpInput, setScaleIpInput] = useState('');
  const [scalePortInput, setScalePortInput] = useState('8899');
  const [scaleIsSimulator, setScaleIsSimulator] = useState(false);

  const [firmNameInput, setFirmNameInput] = useState('');
  const [recipeFirmId, setRecipeFirmId] = useState('');
  const [recipeNameInput, setRecipeNameInput] = useState('');
  const [selectedRecipeForItems, setSelectedRecipeForItems] = useState(null);
  const [itemNameInput, setItemNameInput] = useState('');
  const [itemAmountInput, setItemAmountInput] = useState('');
  const [itemToleranceInput, setItemToleranceInput] = useState('');

  const [orderFirmId, setOrderFirmId] = useState('');
  const [orderRecipeId, setOrderRecipeId] = useState('');
  const [orderTotalAmount, setOrderTotalAmount] = useState('');
  const [orderBagWeight, setOrderBagWeight] = useState('20');
  const [orderBatchCount, setOrderBatchCount] = useState('1');

  const [newUserName, setNewUserName] = useState('');
  const [newUserPass, setNewUserPass] = useState('');
  const [newUserRole, setNewUserRole] = useState('operator');

  // Helper to flash messages
  const showMessage = (type, msg) => {
    if (type === 'error') {
      setErrorMsg(msg);
      setTimeout(() => setErrorMsg(null), 4000);
    } else {
      setSuccessMsg(msg);
      setTimeout(() => setSuccessMsg(null), 4000);
    }
  };

  // Initial Check & DB Polling
  useEffect(() => {
    const fetchInitial = async () => {
      try {
        const data = await api.fetchDb();
        setDb(data);
      } catch (e) {
        console.error('Initial fetch failed:', e);
      }
    };
    fetchInitial();

    const interval = setInterval(async () => {
      try {
        const data = await api.fetchDb();
        setDb(data);
      } catch (e) {
        // silently retry
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Sync active batch logs when DB updates
  useEffect(() => {
    if (activeBatch && db.logs) {
      const currentLogs = db.logs.filter((l) => l.batchId === activeBatch.id);
      setLogsForCurrentBatch(currentLogs);
    }
  }, [db.logs, activeBatch]);

  // Handle Login
  const handleLogin = async () => {
    if (!usernameInput.trim()) {
      showMessage('error', 'Kullanıcı Adı giriniz!');
      return;
    }
    if (roleInput === 'operator' && !passwordInput.trim()) {
      showMessage('error', 'Şifre giriniz!');
      return;
    }

    setLoading(true);
    try {
      const res = await api.login(usernameInput, passwordInput, roleInput === 'operator' ? 'operator' : 'admin');
      if (res.success) {
        setUser(res.user);
        showMessage('success', `Hoş geldiniz, ${res.user.name}`);
        if (res.user.role === 'admin' || res.user.role === 'manager' || res.user.role === 'secretary') {
          setScreen('admin');
        } else {
          setScreen('station-select');
        }
      } else {
        showMessage('error', res.message || 'Giriş başarısız!');
      }
    } catch (e) {
      showMessage('error', e.message || 'Sunucu bağlantı hatası!');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await api.logout();
    } catch (e) {}
    setUser(null);
    if (socketRef.current) {
      socketRef.current.destroy();
      socketRef.current = null;
    }
    setConnected(false);
    setSelectedScale(null);
    setActiveBatch(null);
    setActiveOrder(null);
    setScreen('login');
  };

  // Connect Scale (Physical TCP or Simulated)
  const connectToScale = async (scale) => {
    setSelectedScale(scale);
    setLoading(true);

    if (scale.is_simulator) {
      try {
        await api.connectScale(scale.id);
        setConnected(true);
        showMessage('success', `${scale.name} (Simülasyon) bağlantısı başarılı!`);
        setScreen('job-queue');
      } catch (e) {
        showMessage('error', 'Simülatör bağlantı hatası!');
      } finally {
        setLoading(false);
      }
      return;
    }

    // Physical TCP Socket Connection
    if (socketRef.current) {
      socketRef.current.destroy();
      socketRef.current = null;
    }

    let buffer = '';
    const client = TcpSocket.createConnection(
      {
        host: scale.ip,
        port: Number(scale.port),
        timeout: 5000,
      },
      () => {
        setConnected(true);
        setLoading(false);
        showMessage('success', `${scale.name} bağlantısı kuruldu.`);
        setScreen('job-queue');
      }
    );

    socketRef.current = client;

    client.on('data', (data) => {
      // Decode Uint8Array buffer
      const str = data.toString('ascii');
      buffer += str;
      let lines = buffer.split('\n');
      buffer = lines.pop(); // keep remainder

      lines.forEach((line) => {
        const clean = line.replace('\r', '').trim();
        const match = clean.match(/([+\-]?\s*\d+[\.,]?\d*)\s*(?:k?g|gr?)/i);
        if (match) {
          const valStr = match[1].replace(/\s+/g, '').replace(',', '.');
          const val = parseFloat(valStr);
          if (!isNaN(val)) {
            setWeight(val);
          }
        }
      });
    });

    client.on('error', (error) => {
      console.log('TCP Error:', error);
      setConnected(false);
      setLoading(false);
      showMessage('error', `Terazi bağlantı hatası: ${error.message}`);
    });

    client.on('close', () => {
      setConnected(false);
      setLoading(false);
    });
  };

  // Polling simulated weight if simulator is selected
  useEffect(() => {
    let interval;
    if (selectedScale && selectedScale.is_simulator && connected) {
      interval = setInterval(async () => {
        try {
          const res = await api.getScaleWeight(selectedScale.id);
          if (res.success) {
            setWeight(res.weight);
          }
        } catch (e) {}
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [selectedScale, connected]);

  // Haptic Vibration Check when Weight matches target & tolerance
  useEffect(() => {
    if (screen === 'checklist' && activeRecipeItems.length > 0 && currentItemIndex < activeRecipeItems.length) {
      const item = activeRecipeItems[currentItemIndex];
      const diff = Math.abs(weight - item.amount);
      if (diff <= item.tolerance && weight > 0) {
        // Target achieved within tolerance! Trigger Haptic Vibration
        Vibration.vibrate([0, 100, 100, 100]);
      }
    }
  }, [weight, screen, currentItemIndex, activeRecipeItems]);

  // Start or Continue Batch
  const handleSelectBatch = async (order, batch) => {
    setLoading(true);
    try {
      if (batch.status === 'beklemede') {
        const res = await api.startBatch(batch.id, user ? user.name : 'Operatör');
        if (res.success) {
          setActiveBatch(res.batch);
        }
      } else {
        setActiveBatch(batch);
      }
      setActiveOrder(order);
      setActiveRecipeItems(order.recipeItems || []);
      setCurrentItemIndex(0);
      setScreen('checklist');
    } catch (e) {
      showMessage('error', 'İş emri başlatılamadı!');
    } finally {
      setLoading(false);
    }
  };

  // Approve current recipe item
  const handleApproveItem = async () => {
    if (currentItemIndex >= activeRecipeItems.length) return;
    const item = activeRecipeItems[currentItemIndex];

    setLoading(true);
    try {
      await api.addLog(
        activeBatch.id,
        user ? user.name : 'Operatör',
        activeOrder.customer,
        activeOrder.recipeName,
        item.name,
        item.amount,
        weight,
        'Başarılı'
      );
      showMessage('success', `${item.name} başarıyla onaylandı.`);

      if (currentItemIndex + 1 < activeRecipeItems.length) {
        setCurrentItemIndex(currentItemIndex + 1);
      } else {
        // All items done, move to packaging
        await api.updateBatchStatus(activeBatch.id, 'paketlemede');
        activeBatch.status = 'paketlemede';
        setActiveBatch({ ...activeBatch });
        setScreen('packaging');
      }
    } catch (e) {
      showMessage('error', 'Log eklenirken hata oluştu!');
    } finally {
      setLoading(false);
    }
  };

  // Finish packaging
  const handleFinishPackaging = async () => {
    setLoading(true);
    try {
      await api.finishBatch(activeBatch.id);
      showMessage('success', 'Paketleme tamamlandı! Fiş kesimi için bekleniyor.');
      setScreen('job-queue');
      setActiveBatch(null);
      setActiveOrder(null);
    } catch (e) {
      showMessage('error', 'İşlem tamamlanamadı!');
    } finally {
      setLoading(false);
    }
  };

  // --- ADMIN FUNCTIONS ---
  const handleAddScale = async () => {
    if (!scaleNameInput || !scaleIpInput) {
      showMessage('error', 'Terazi Adı ve IP alanları zorunludur!');
      return;
    }
    setLoading(true);
    try {
      await api.addScale(scaleNameInput, scaleIpInput, scalePortInput, scaleIsSimulator);
      showMessage('success', 'Terazi başarıyla eklendi.');
      setScaleNameInput('');
      setScaleIpInput('');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteScale = async (id) => {
    setLoading(true);
    try {
      await api.deleteScale(id);
      showMessage('success', 'Terazi silindi.');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddFirm = async () => {
    if (!firmNameInput) {
      showMessage('error', 'Firma adı boş olamaz!');
      return;
    }
    setLoading(true);
    try {
      await api.addFirm(firmNameInput);
      showMessage('success', 'Firma eklendi.');
      setFirmNameInput('');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteFirm = async (id) => {
    setLoading(true);
    try {
      await api.deleteFirm(id);
      showMessage('success', 'Firma silindi.');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddRecipe = async () => {
    if (!recipeFirmId || !recipeNameInput) {
      showMessage('error', 'Firma seçimi ve reçete adı zorunludur!');
      return;
    }
    setLoading(true);
    try {
      await api.addRecipe(recipeFirmId, recipeNameInput);
      showMessage('success', 'Reçete oluşturuldu.');
      setRecipeNameInput('');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteRecipe = async (id) => {
    setLoading(true);
    try {
      await api.deleteRecipe(id);
      showMessage('success', 'Reçete silindi.');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddRecipeItem = async () => {
    if (!selectedRecipeForItems || !itemNameInput || !itemAmountInput || !itemToleranceInput) {
      showMessage('error', 'Tüm hammadde alanları zorunludur!');
      return;
    }
    setLoading(true);
    try {
      await api.addRecipeItem(
        selectedRecipeForItems.id,
        itemNameInput,
        parseFloat(itemAmountInput),
        parseFloat(itemToleranceInput)
      );
      showMessage('success', 'Hammadde eklendi.');
      setItemNameInput('');
      setItemAmountInput('');
      setItemToleranceInput('');
      const data = await api.fetchDb();
      setDb(data);
      const updated = data.recipes.find((r) => r.id === selectedRecipeForItems.id);
      setSelectedRecipeForItems(updated);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteRecipeItem = async (recipeId, itemId) => {
    setLoading(true);
    try {
      await api.deleteRecipeItem(recipeId, itemId);
      showMessage('success', 'Hammadde silindi.');
      const data = await api.fetchDb();
      setDb(data);
      const updated = data.recipes.find((r) => r.id === recipeId);
      setSelectedRecipeForItems(updated);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateOrder = async () => {
    if (!orderFirmId || !orderRecipeId || !orderTotalAmount) {
      showMessage('error', 'Firma, Reçete ve Toplam Miktar zorunludur!');
      return;
    }
    setLoading(true);
    try {
      await api.createOrder(
        orderFirmId,
        orderRecipeId,
        parseFloat(orderTotalAmount),
        parseFloat(orderBagWeight || 20),
        parseInt(orderBatchCount || 1)
      );
      showMessage('success', 'İş emri oluşturuldu.');
      setOrderTotalAmount('');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteOrder = async (batchId) => {
    setLoading(true);
    try {
      await api.deleteBatch(batchId);
      showMessage('success', 'İş emri silindi.');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAddUser = async () => {
    if (!newUserName || !newUserPass) {
      showMessage('error', 'Kullanıcı adı ve şifre zorunludur!');
      return;
    }
    setLoading(true);
    try {
      await api.addUser(newUserName, newUserPass, newUserRole);
      showMessage('success', 'Personel eklendi.');
      setNewUserName('');
      setNewUserPass('');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (id) => {
    setLoading(true);
    try {
      await api.deleteUser(id);
      showMessage('success', 'Personel silindi.');
      const data = await api.fetchDb();
      setDb(data);
    } catch (e) {
      showMessage('error', e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* HEADER BAR */}
      <View style={styles.headerBar}>
        <View style={styles.headerLeft}>
          {screen !== 'login' && screen !== 'station-select' && screen !== 'admin' && (
            <TouchableOpacity style={styles.backBtn} onPress={() => setScreen('station-select')}>
              <Text style={styles.backBtnText}>← Teraziler</Text>
            </TouchableOpacity>
          )}
          <Text style={styles.appTitle}>BAHARAT OTOMASYON</Text>
        </View>

        <View style={styles.headerCenter}>
          {connected && selectedScale && (
            <View style={styles.connectionBadge}>
              <View style={[styles.statusDot, { backgroundColor: '#10b981' }]} />
              <Text style={styles.connectionText}>{selectedScale.name}</Text>
            </View>
          )}
        </View>

        <View style={styles.headerRight}>
          {user && (
            <View style={styles.userInfo}>
              <Text style={styles.userNameText}>{user.name}</Text>
              <Text style={styles.userRoleText}>({user.role})</Text>
              <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
                <Text style={styles.logoutBtnText}>Çıkış</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </View>

      {/* FLASH MESSAGES */}
      {errorMsg && (
        <View style={[styles.alertBox, styles.alertError]}>
          <Text style={styles.alertText}>{errorMsg}</Text>
        </View>
      )}
      {successMsg && (
        <View style={[styles.alertBox, styles.alertSuccess]}>
          <Text style={styles.alertText}>{successMsg}</Text>
        </View>
      )}

      {/* SPINNER */}
      {loading && (
        <View style={styles.spinnerContainer}>
          <ActivityIndicator size="large" color="#f97316" />
        </View>
      )}

      {/* 1. LOGIN SCREEN */}
      {screen === 'login' && (
        <View style={styles.loginContainer}>
          <View style={styles.loginCard}>
            <Text style={styles.loginHeader}>Sisteme Giriş</Text>
            <Text style={styles.loginSubheader}>Rolünüzü seçin ve bilgilerinizi girin</Text>

            <View style={styles.roleTabContainer}>
              <TouchableOpacity
                style={[styles.roleTab, roleInput === 'operator' && styles.roleTabActive]}
                onPress={() => setRoleInput('operator')}>
                <Text style={[styles.roleTabText, roleInput === 'operator' && styles.roleTabTextActive]}>
                  Operatör
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.roleTab, roleInput === 'manager' && styles.roleTabActive]}
                onPress={() => setRoleInput('manager')}>
                <Text style={[styles.roleTabText, roleInput === 'manager' && styles.roleTabTextActive]}>
                  Yönetici
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.roleTab, roleInput === 'secretary' && styles.roleTabActive]}
                onPress={() => setRoleInput('secretary')}>
                <Text style={[styles.roleTabText, roleInput === 'secretary' && styles.roleTabTextActive]}>
                  Sekreter
                </Text>
              </TouchableOpacity>
            </View>

            <TextInput
              style={styles.inputField}
              placeholder="Kullanıcı Adı"
              placeholderTextColor="#94a3b8"
              value={usernameInput}
              onChangeText={setUsernameInput}
              autoCapitalize="none"
            />

            {roleInput === 'operator' && (
              <TextInput
                style={styles.inputField}
                placeholder="Şifre (Örn: 1111)"
                placeholderTextColor="#94a3b8"
                secureTextEntry
                value={passwordInput}
                onChangeText={setPasswordInput}
              />
            )}

            <TouchableOpacity style={styles.btnOrange} onPress={handleLogin}>
              <Text style={styles.btnOrangeText}>GİRİŞ YAP</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* 2. STATION SELECTION SCREEN (Operators) */}
      {screen === 'station-select' && (
        <View style={styles.mainContainer}>
          <Text style={styles.sectionTitle}>Çalışma İstasyonu (Terazi) Seçiniz</Text>
          <Text style={styles.sectionSubtitle}>
            Bağlanmak istediğiniz fiziksel TCP terazisini veya simülatörü seçin
          </Text>

          <FlatList
            data={db.scales}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={styles.gridContainer}
            renderItem={({ item }) => (
              <TouchableOpacity style={styles.scaleCard} onPress={() => connectToScale(item)}>
                <View style={styles.scaleCardHeader}>
                  <View style={[styles.statusDot, { backgroundColor: item.status ? '#10b981' : '#dc2626' }]} />
                  <Text style={styles.scaleCardTitle}>{item.name}</Text>
                </View>
                <Text style={styles.scaleCardDetail}>
                  IP: {item.ip}:{item.port}
                </Text>
                <Text style={styles.scaleCardType}>
                  {item.is_simulator ? 'Simülasyon Modu (HTTP)' : 'Fiziksel Terazi (TCP Socket)'}
                </Text>
                <View style={styles.btnConnect}>
                  <Text style={styles.btnConnectText}>Bağlan & Üretime Başla</Text>
                </View>
              </TouchableOpacity>
            )}
          />
        </View>
      )}

      {/* 3. JOB QUEUE SCREEN */}
      {screen === 'job-queue' && (
        <View style={styles.mainContainer}>
          <Text style={styles.sectionTitle}>Aktif İş Emirleri (Partiler)</Text>
          <Text style={styles.sectionSubtitle}>Üretime başlamak veya devam etmek için bir parti seçin</Text>

          <FlatList
            data={db.orders}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={styles.listContainer}
            renderItem={({ item: order }) => (
              <View style={styles.orderCard}>
                <View style={styles.orderCardHeader}>
                  <Text style={styles.orderCustomer}>{order.customer}</Text>
                  <Text style={styles.orderRecipe}>{order.recipeName}</Text>
                </View>
                <Text style={styles.orderTotal}>Toplam: {order.totalAmount} kg</Text>

                <View style={styles.batchesContainer}>
                  {order.batches &&
                    order.batches.map((batch) => {
                      let badgeColor = '#64748b';
                      if (batch.status === 'tartımda') badgeColor = '#f97316';
                      if (batch.status === 'mikserde') badgeColor = '#a855f7';
                      if (batch.status === 'paketlemede') badgeColor = '#0ea5e9';
                      if (batch.status === 'fiş kesilmedi') badgeColor = '#dc2626';
                      if (batch.status === 'tamamlandı') badgeColor = '#10b981';

                      return (
                        <TouchableOpacity
                          key={batch.id}
                          style={styles.batchRow}
                          onPress={() => handleSelectBatch(order, batch)}>
                          <View>
                            <Text style={styles.batchTitle}>
                              Parti #{batch.no} / {batch.totalBatches} ({batch.targetAmount} kg)
                            </Text>
                            {batch.operator && <Text style={styles.batchOperator}>Operatör: {batch.operator}</Text>}
                          </View>

                          <View style={[styles.statusBadge, { backgroundColor: badgeColor }]}>
                            <Text style={styles.statusBadgeText}>{batch.status.toUpperCase()}</Text>
                          </View>
                        </TouchableOpacity>
                      );
                    })}
                </View>
              </View>
            )}
          />
        </View>
      )}

      {/* 4. ACTIVE WEIGHING CHECKLIST SCREEN */}
      {screen === 'checklist' && activeBatch && activeOrder && (
        <View style={styles.checklistContainer}>
          {/* DIGITAL WEIGHT DISPLAY */}
          <View style={styles.weightDisplayCard}>
            <Text style={styles.weightLabel}>CANLI TERAZİ AĞIRLIĞI</Text>
            <Text style={styles.weightValue}>{weight.toFixed(2)} kg</Text>
            <Text style={styles.weightSource}>
              {selectedScale?.name} ({selectedScale?.is_simulator ? 'HTTP' : 'TCP Socket'})
            </Text>
          </View>

          <Text style={styles.checklistHeader}>
            {activeOrder.recipeName} — Parti #{activeBatch.no}
          </Text>

          {/* INGREDIENTS LIST */}
          <ScrollView style={styles.ingredientsScroll}>
            {activeRecipeItems.map((item, index) => {
              const isDone = index < currentItemIndex;
              const isCurrent = index === currentItemIndex;

              let rowStyle = styles.itemRow;
              if (isDone) rowStyle = [styles.itemRow, styles.itemRowDone];
              if (isCurrent) rowStyle = [styles.itemRow, styles.itemRowCurrent];

              let diff = Math.abs(weight - item.amount);
              let withinTolerance = isCurrent && diff <= item.tolerance && weight > 0;

              return (
                <View key={item.id || index} style={rowStyle}>
                  <View style={styles.itemInfo}>
                    <Text style={[styles.itemName, isDone && styles.textLineThrough]}>{item.name}</Text>
                    <Text style={styles.itemTarget}>
                      Hedef: {item.amount} kg (±{item.tolerance} kg)
                    </Text>
                  </View>

                  <View style={styles.itemAction}>
                    {isDone && (
                      <View style={styles.badgeSuccess}>
                        <Text style={styles.badgeSuccessText}>ONAYLANDI</Text>
                      </View>
                    )}

                    {isCurrent && (
                      <View style={styles.currentActionBox}>
                        <View
                          style={[
                            styles.toleranceIndicator,
                            withinTolerance ? styles.indicatorGood : styles.indicatorWait,
                          ]}>
                          <Text style={styles.indicatorText}>
                            {withinTolerance ? 'TOLERANS UYGUN' : 'AĞIRLIK BEKLENİYOR'}
                          </Text>
                        </View>

                        <TouchableOpacity
                          style={[styles.btnApprove, withinTolerance ? styles.btnApproveActive : styles.btnApproveOverride]}
                          onPress={handleApproveItem}>
                          <Text style={styles.btnApproveText}>
                            {withinTolerance ? 'TARTIMI ONAYLA' : 'MANUEL ONAYLA (ZORLA)'}
                          </Text>
                        </TouchableOpacity>
                      </View>
                    )}

                    {!isDone && !isCurrent && (
                      <View style={styles.badgePending}>
                        <Text style={styles.badgePendingText}>SIRADA</Text>
                      </View>
                    )}
                  </View>
                </View>
              );
            })}
          </ScrollView>

          {/* LOGS FOR THIS BATCH */}
          <View style={styles.logsCard}>
            <Text style={styles.logsCardTitle}>Gerçekleşen Tartım Logları</Text>
            {logsForCurrentBatch.length === 0 ? (
              <Text style={styles.noLogsText}>Henüz onaylanmış tartım bulunmamaktadır.</Text>
            ) : (
              logsForCurrentBatch.map((l, i) => (
                <Text key={i} style={styles.logTextItem}>
                  ✓ {l.item}: {l.actual} kg ({l.status}) - {l.operator}
                </Text>
              ))
            )}
          </View>
        </View>
      )}

      {/* 5. PACKAGING SCREEN */}
      {screen === 'packaging' && activeBatch && activeOrder && (
        <View style={styles.mainContainer}>
          <View style={styles.packagingCard}>
            <Text style={styles.packagingTitle}>Çuval / Paketleme Özeti</Text>
            <Text style={styles.packagingCustomer}>
              {activeOrder.customer} — {activeOrder.recipeName}
            </Text>

            <View style={styles.packagingDetailsBox}>
              <Text style={styles.packagingDetailItem}>
                Parti Numarası: #{activeBatch.no} / {activeBatch.totalBatches}
              </Text>
              <Text style={styles.packagingDetailItem}>Parti Hedef Miktarı: {activeBatch.targetAmount} kg</Text>
              <Text style={styles.packagingDetailItem}>Tek Torba Ağırlığı: {activeBatch.bagWeight || 20} kg</Text>

              <View style={styles.divider} />

              <Text style={styles.calculationHighlight}>
                Hedeflenen Toplam Çuval Sayısı:{' '}
                {Math.ceil(activeBatch.targetAmount / (activeBatch.bagWeight || 20))} adet
              </Text>
            </View>

            <TouchableOpacity style={styles.btnSuccessLarge} onPress={handleFinishPackaging}>
              <Text style={styles.btnSuccessLargeText}>PAKETLEMEYİ BİTİR & İŞ EMRİNİ TAMAMLA</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* 6. ADMIN / MANAGER DASHBOARD */}
      {screen === 'admin' && (
        <View style={styles.adminContainer}>
          {/* SUB TABS */}
          <View style={styles.adminTabHeader}>
            <TouchableOpacity
              style={[styles.adminTabBtn, adminTab === 'scales' && styles.adminTabBtnActive]}
              onPress={() => setAdminTab('scales')}>
              <Text style={[styles.adminTabBtnText, adminTab === 'scales' && styles.adminTabBtnTextActive]}>
                Teraziler
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.adminTabBtn, adminTab === 'firms' && styles.adminTabBtnActive]}
              onPress={() => setAdminTab('firms')}>
              <Text style={[styles.adminTabBtnText, adminTab === 'firms' && styles.adminTabBtnTextActive]}>
                Firmalar
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.adminTabBtn, adminTab === 'recipes' && styles.adminTabBtnActive]}
              onPress={() => setAdminTab('recipes')}>
              <Text style={[styles.adminTabBtnText, adminTab === 'recipes' && styles.adminTabBtnTextActive]}>
                Reçeteler
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.adminTabBtn, adminTab === 'orders' && styles.adminTabBtnActive]}
              onPress={() => setAdminTab('orders')}>
              <Text style={[styles.adminTabBtnText, adminTab === 'orders' && styles.adminTabBtnTextActive]}>
                İş Emirleri
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.adminTabBtn, adminTab === 'users' && styles.adminTabBtnActive]}
              onPress={() => setAdminTab('users')}>
              <Text style={[styles.adminTabBtnText, adminTab === 'users' && styles.adminTabBtnTextActive]}>
                Personel
              </Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.adminScrollContent}>
            {/* SCALES TAB */}
            {adminTab === 'scales' && (
              <View style={styles.adminSectionCard}>
                <Text style={styles.adminSectionTitle}>Yeni Terazi / İstasyon Ekle</Text>
                <TextInput
                  style={styles.inputField}
                  placeholder="Terazi Adı (Örn: Hat 1 Terazisi)"
                  placeholderTextColor="#94a3b8"
                  value={scaleNameInput}
                  onChangeText={setScaleNameInput}
                />
                <TextInput
                  style={styles.inputField}
                  placeholder="IP Adresi (Örn: 192.168.1.101)"
                  placeholderTextColor="#94a3b8"
                  value={scaleIpInput}
                  onChangeText={setScaleIpInput}
                />
                <TextInput
                  style={styles.inputField}
                  placeholder="Port (Örn: 8899)"
                  placeholderTextColor="#94a3b8"
                  value={scalePortInput}
                  onChangeText={setScalePortInput}
                  keyboardType="numeric"
                />
                <TouchableOpacity
                  style={styles.toggleRow}
                  onPress={() => setScaleIsSimulator(!scaleIsSimulator)}>
                  <Text style={styles.toggleLabel}>Simülasyon Modu mu?</Text>
                  <View style={[styles.toggleBtn, scaleIsSimulator && styles.toggleBtnActive]}>
                    <Text style={styles.toggleBtnText}>{scaleIsSimulator ? 'EVET' : 'HAYIR'}</Text>
                  </View>
                </TouchableOpacity>

                <TouchableOpacity style={styles.btnBlue} onPress={handleAddScale}>
                  <Text style={styles.btnBlueText}>TERAZİ EKLE</Text>
                </TouchableOpacity>

                <View style={styles.tableCard}>
                  <Text style={styles.tableTitle}>Mevcut Teraziler</Text>
                  {db.scales.map((s) => (
                    <View key={s.id} style={styles.tableRow}>
                      <View>
                        <Text style={styles.tableItemTitle}>{s.name}</Text>
                        <Text style={styles.tableItemSub}>
                          {s.ip}:{s.port} ({s.is_simulator ? 'Simülatör' : 'Fiziksel'})
                        </Text>
                      </View>
                      <TouchableOpacity style={styles.btnDelete} onPress={() => handleDeleteScale(s.id)}>
                        <Text style={styles.btnDeleteText}>Sil</Text>
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              </View>
            )}

            {/* FIRMS TAB */}
            {adminTab === 'firms' && (
              <View style={styles.adminSectionCard}>
                <Text style={styles.adminSectionTitle}>Yeni Firma Ekle</Text>
                <TextInput
                  style={styles.inputField}
                  placeholder="Firma Adı"
                  placeholderTextColor="#94a3b8"
                  value={firmNameInput}
                  onChangeText={setFirmNameInput}
                />
                <TouchableOpacity style={styles.btnBlue} onPress={handleAddFirm}>
                  <Text style={styles.btnBlueText}>FİRMA EKLE</Text>
                </TouchableOpacity>

                <View style={styles.tableCard}>
                  <Text style={styles.tableTitle}>Kayıtlı Firmalar</Text>
                  {db.firms.map((f) => (
                    <View key={f.id} style={styles.tableRow}>
                      <Text style={styles.tableItemTitle}>{f.name}</Text>
                      <TouchableOpacity style={styles.btnDelete} onPress={() => handleDeleteFirm(f.id)}>
                        <Text style={styles.btnDeleteText}>Sil</Text>
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              </View>
            )}

            {/* RECIPES TAB */}
            {adminTab === 'recipes' && (
              <View style={styles.adminSectionCard}>
                <Text style={styles.adminSectionTitle}>Yeni Reçete Ekle</Text>
                <Text style={styles.fieldLabel}>Firma Seçin:</Text>
                <View style={styles.selectionPills}>
                  {db.firms.map((f) => (
                    <TouchableOpacity
                      key={f.id}
                      style={[styles.pillBtn, recipeFirmId === f.id && styles.pillBtnActive]}
                      onPress={() => setRecipeFirmId(f.id)}>
                      <Text style={[styles.pillBtnText, recipeFirmId === f.id && styles.pillBtnTextActive]}>
                        {f.name}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <TextInput
                  style={styles.inputField}
                  placeholder="Reçete Adı"
                  placeholderTextColor="#94a3b8"
                  value={recipeNameInput}
                  onChangeText={setRecipeNameInput}
                />
                <TouchableOpacity style={styles.btnBlue} onPress={handleAddRecipe}>
                  <Text style={styles.btnBlueText}>REÇETE OLUŞTUR</Text>
                </TouchableOpacity>

                <View style={styles.tableCard}>
                  <Text style={styles.tableTitle}>Reçeteler & Hammadde Düzenleme</Text>
                  {db.recipes.map((r) => {
                    const isExpanded = selectedRecipeForItems?.id === r.id;
                    return (
                      <View key={r.id} style={styles.recipeMasterCard}>
                        <View style={styles.recipeMasterRow}>
                          <View>
                            <Text style={styles.tableItemTitle}>{r.name}</Text>
                            <Text style={styles.tableItemSub}>Firma ID: {r.firmId}</Text>
                          </View>

                          <View style={styles.rowButtons}>
                            <TouchableOpacity
                              style={styles.btnToggleExpand}
                              onPress={() => setSelectedRecipeForItems(isExpanded ? null : r)}>
                              <Text style={styles.btnToggleExpandText}>
                                {isExpanded ? 'Gizle' : 'Hammaddeler'}
                              </Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.btnDelete} onPress={() => handleDeleteRecipe(r.id)}>
                              <Text style={styles.btnDeleteText}>Sil</Text>
                            </TouchableOpacity>
                          </View>
                        </View>

                        {isExpanded && (
                          <View style={styles.itemsSubCard}>
                            <Text style={styles.itemsSubCardTitle}>Reçete İçeriği (Hammaddeler)</Text>
                            {r.items && r.items.length === 0 ? (
                              <Text style={styles.noLogsText}>Henüz hammadde eklenmemiş.</Text>
                            ) : (
                              r.items.map((item) => (
                                <View key={item.id} style={styles.itemMasterRow}>
                                  <Text style={styles.itemMasterText}>
                                    {item.name}: {item.amount} kg (±{item.tolerance} kg)
                                  </Text>
                                  <TouchableOpacity
                                    style={styles.btnDeleteSmall}
                                    onPress={() => handleDeleteRecipeItem(r.id, item.id)}>
                                    <Text style={styles.btnDeleteSmallText}>X</Text>
                                  </TouchableOpacity>
                                </View>
                              ))
                            )}

                            <View style={styles.addItemForm}>
                              <TextInput
                                style={styles.inputFieldSmall}
                                placeholder="Hammadde Adı (Örn: Tuz)"
                                placeholderTextColor="#94a3b8"
                                value={itemNameInput}
                                onChangeText={setItemNameInput}
                              />
                              <TextInput
                                style={styles.inputFieldSmall}
                                placeholder="Miktar kg (Örn: 15)"
                                placeholderTextColor="#94a3b8"
                                value={itemAmountInput}
                                onChangeText={setItemAmountInput}
                                keyboardType="numeric"
                              />
                              <TextInput
                                style={styles.inputFieldSmall}
                                placeholder="Tolerans kg (Örn: 0.2)"
                                placeholderTextColor="#94a3b8"
                                value={itemToleranceInput}
                                onChangeText={setItemToleranceInput}
                                keyboardType="numeric"
                              />
                              <TouchableOpacity style={styles.btnGreenSmall} onPress={handleAddRecipeItem}>
                                <Text style={styles.btnGreenSmallText}>+ HAMMADDE EKLE</Text>
                              </TouchableOpacity>
                            </View>
                          </View>
                        )}
                      </View>
                    );
                  })}
                </View>
              </View>
            )}

            {/* ORDERS TAB */}
            {adminTab === 'orders' && (
              <View style={styles.adminSectionCard}>
                <Text style={styles.adminSectionTitle}>Yeni İş Emri Oluştur</Text>

                <Text style={styles.fieldLabel}>Firma:</Text>
                <View style={styles.selectionPills}>
                  {db.firms.map((f) => (
                    <TouchableOpacity
                      key={f.id}
                      style={[styles.pillBtn, orderFirmId === f.id && styles.pillBtnActive]}
                      onPress={() => setOrderFirmId(f.id)}>
                      <Text style={[styles.pillBtnText, orderFirmId === f.id && styles.pillBtnTextActive]}>
                        {f.name}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <Text style={styles.fieldLabel}>Reçete:</Text>
                <View style={styles.selectionPills}>
                  {db.recipes
                    .filter((r) => !orderFirmId || r.firmId === orderFirmId)
                    .map((r) => (
                      <TouchableOpacity
                        key={r.id}
                        style={[styles.pillBtn, orderRecipeId === r.id && styles.pillBtnActive]}
                        onPress={() => setOrderRecipeId(r.id)}>
                        <Text style={[styles.pillBtnText, orderRecipeId === r.id && styles.pillBtnTextActive]}>
                          {r.name}
                        </Text>
                      </TouchableOpacity>
                    ))}
                </View>

                <TextInput
                  style={styles.inputField}
                  placeholder="Toplam Sipariş Miktarı kg (Örn: 300)"
                  placeholderTextColor="#94a3b8"
                  value={orderTotalAmount}
                  onChangeText={setOrderTotalAmount}
                  keyboardType="numeric"
                />
                <TextInput
                  style={styles.inputField}
                  placeholder="Çuval/Paket Ağırlığı kg (Örn: 20)"
                  placeholderTextColor="#94a3b8"
                  value={orderBagWeight}
                  onChangeText={setOrderBagWeight}
                  keyboardType="numeric"
                />
                <TextInput
                  style={styles.inputField}
                  placeholder="Parti (Batch) Sayısı (Örn: 3)"
                  placeholderTextColor="#94a3b8"
                  value={orderBatchCount}
                  onChangeText={setOrderBatchCount}
                  keyboardType="numeric"
                />

                <TouchableOpacity style={styles.btnBlue} onPress={handleCreateOrder}>
                  <Text style={styles.btnBlueText}>İŞ EMRİ BAŞLAT</Text>
                </TouchableOpacity>

                <View style={styles.tableCard}>
                  <Text style={styles.tableTitle}>Mevcut İş Emirleri</Text>
                  {db.orders.map((o) => (
                    <View key={o.id} style={styles.orderMasterCard}>
                      <Text style={styles.tableItemTitle}>
                        {o.customer} - {o.recipeName}
                      </Text>
                      <Text style={styles.tableItemSub}>Toplam: {o.totalAmount} kg</Text>

                      {o.batches &&
                        o.batches.map((b) => (
                          <View key={b.id} style={styles.batchAdminRow}>
                            <Text style={styles.batchAdminText}>
                              Parti #{b.no}: {b.targetAmount} kg ({b.status})
                            </Text>
                            <TouchableOpacity style={styles.btnDeleteSmall} onPress={() => handleDeleteOrder(b.id)}>
                              <Text style={styles.btnDeleteSmallText}>Sil</Text>
                            </TouchableOpacity>
                          </View>
                        ))}
                    </View>
                  ))}
                </View>
              </View>
            )}

            {/* USERS TAB */}
            {adminTab === 'users' && (
              <View style={styles.adminSectionCard}>
                <Text style={styles.adminSectionTitle}>Personel & Yetki Yönetimi</Text>
                <TextInput
                  style={styles.inputField}
                  placeholder="Personel Adı"
                  placeholderTextColor="#94a3b8"
                  value={newUserName}
                  onChangeText={setNewUserName}
                />
                <TextInput
                  style={styles.inputField}
                  placeholder="Şifre"
                  placeholderTextColor="#94a3b8"
                  value={newUserPass}
                  onChangeText={setNewUserPass}
                />

                <Text style={styles.fieldLabel}>Rol:</Text>
                <View style={styles.selectionPills}>
                  {['operator', 'manager', 'secretary'].map((role) => (
                    <TouchableOpacity
                      key={role}
                      style={[styles.pillBtn, newUserRole === role && styles.pillBtnActive]}
                      onPress={() => setNewUserRole(role)}>
                      <Text style={[styles.pillBtnText, newUserRole === role && styles.pillBtnTextActive]}>
                        {role.toUpperCase()}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <TouchableOpacity style={styles.btnBlue} onPress={handleAddUser}>
                  <Text style={styles.btnBlueText}>PERSONEL EKLE</Text>
                </TouchableOpacity>

                <View style={styles.tableCard}>
                  <Text style={styles.tableTitle}>Kayıtlı Personeller</Text>
                  {db.users.map((u) => (
                    <View key={u.id} style={styles.tableRow}>
                      <View>
                        <Text style={styles.tableItemTitle}>{u.name}</Text>
                        <Text style={styles.tableItemSub}>Rol: {u.role}</Text>
                      </View>
                      {u.role !== 'admin' && (
                        <TouchableOpacity style={styles.btnDelete} onPress={() => handleDeleteUser(u.id)}>
                          <Text style={styles.btnDeleteText}>Sil</Text>
                        </TouchableOpacity>
                      )}
                    </View>
                  ))}
                </View>
              </View>
            )}
          </ScrollView>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617', // slate-950
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#0f172a', // slate-900
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#1e293b',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backBtn: {
    marginRight: 15,
    backgroundColor: '#1e293b',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  backBtnText: {
    color: '#cbd5e1',
    fontWeight: 'bold',
    fontSize: 14,
  },
  appTitle: {
    color: '#f97316', // orange-500
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: 1,
  },
  headerCenter: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  connectionBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1e293b',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#334155',
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 8,
  },
  connectionText: {
    color: '#10b981',
    fontWeight: 'bold',
    fontSize: 14,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userNameText: {
    color: '#f8fafc',
    fontWeight: 'bold',
    fontSize: 15,
    marginRight: 6,
  },
  userRoleText: {
    color: '#94a3b8',
    fontSize: 13,
    marginRight: 15,
  },
  logoutBtn: {
    backgroundColor: '#dc2626',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 8,
  },
  logoutBtnText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  alertBox: {
    padding: 15,
    marginHorizontal: 20,
    marginTop: 15,
    borderRadius: 12,
    alignItems: 'center',
  },
  alertError: {
    backgroundColor: '#dc2626',
  },
  alertSuccess: {
    backgroundColor: '#10b981',
  },
  alertText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 15,
  },
  spinnerContainer: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    zIndex: 999,
    backgroundColor: 'rgba(15, 23, 42, 0.8)',
    padding: 30,
    borderRadius: 20,
  },
  loginContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loginCard: {
    width: '100%',
    maxWidth: 450,
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 24,
    padding: 35,
    alignItems: 'center',
  },
  loginHeader: {
    fontSize: 28,
    fontWeight: '800',
    color: '#f8fafc',
    marginBottom: 10,
  },
  loginSubheader: {
    fontSize: 15,
    color: '#94a3b8',
    marginBottom: 30,
    textAlign: 'center',
  },
  roleTabContainer: {
    flexDirection: 'row',
    width: '100%',
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 4,
    marginBottom: 25,
  },
  roleTab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 10,
  },
  roleTabActive: {
    backgroundColor: '#f97316',
  },
  roleTabText: {
    color: '#94a3b8',
    fontWeight: 'bold',
    fontSize: 15,
  },
  roleTabTextActive: {
    color: '#ffffff',
  },
  inputField: {
    width: '100%',
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 12,
    paddingHorizontal: 18,
    paddingVertical: 15,
    color: '#ffffff',
    fontSize: 16,
    marginBottom: 20,
  },
  btnOrange: {
    width: '100%',
    backgroundColor: '#f97316',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
  },
  btnOrangeText: {
    color: '#ffffff',
    fontWeight: '800',
    fontSize: 16,
    letterSpacing: 1,
  },
  mainContainer: {
    flex: 1,
    padding: 25,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#f8fafc',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 15,
    color: '#94a3b8',
    marginBottom: 25,
  },
  gridContainer: {
    paddingBottom: 30,
  },
  scaleCard: {
    backgroundColor: '#0f172a',
    borderWidth: 2,
    borderColor: '#1e293b',
    borderRadius: 20,
    padding: 25,
    marginBottom: 20,
  },
  scaleCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  scaleCardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  scaleCardDetail: {
    fontSize: 16,
    color: '#cbd5e1',
    marginBottom: 6,
  },
  scaleCardType: {
    fontSize: 14,
    color: '#94a3b8',
    marginBottom: 20,
  },
  btnConnect: {
    backgroundColor: '#10b981',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  btnConnectText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  listContainer: {
    paddingBottom: 30,
  },
  orderCard: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 20,
    padding: 25,
    marginBottom: 25,
  },
  orderCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  orderCustomer: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#f97316',
  },
  orderRecipe: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#f8fafc',
  },
  orderTotal: {
    fontSize: 16,
    color: '#cbd5e1',
    marginBottom: 20,
  },
  batchesContainer: {
    flexDirection: 'column',
  },
  batchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 14,
    padding: 18,
    marginBottom: 12,
  },
  batchTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  batchOperator: {
    fontSize: 14,
    color: '#94a3b8',
    marginTop: 4,
  },
  statusBadge: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  statusBadgeText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 12,
  },
  checklistContainer: {
    flex: 1,
    padding: 25,
  },
  weightDisplayCard: {
    backgroundColor: '#020617',
    borderWidth: 2,
    borderColor: '#3b82f6',
    borderRadius: 24,
    padding: 30,
    alignItems: 'center',
    marginBottom: 25,
  },
  weightLabel: {
    fontSize: 15,
    color: '#94a3b8',
    fontWeight: 'bold',
    letterSpacing: 1,
    marginBottom: 10,
  },
  weightValue: {
    fontSize: 48,
    fontWeight: '900',
    color: '#10b981',
    marginBottom: 10,
  },
  weightSource: {
    fontSize: 14,
    color: '#cbd5e1',
  },
  checklistHeader: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 20,
  },
  ingredientsScroll: {
    flex: 1,
    marginBottom: 25,
  },
  itemRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 16,
    padding: 20,
    marginBottom: 15,
  },
  itemRowDone: {
    backgroundColor: '#020617',
    borderColor: '#10b981',
    opacity: 0.7,
  },
  itemRowCurrent: {
    borderColor: '#f97316',
    borderWidth: 2,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#f8fafc',
    marginBottom: 6,
  },
  textLineThrough: {
    textDecorationLine: 'line-through',
    color: '#94a3b8',
  },
  itemTarget: {
    fontSize: 15,
    color: '#cbd5e1',
  },
  itemAction: {
    alignItems: 'flex-end',
  },
  badgeSuccess: {
    backgroundColor: '#10b981',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 12,
  },
  badgeSuccessText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 13,
  },
  badgePending: {
    backgroundColor: '#334155',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 12,
  },
  badgePendingText: {
    color: '#cbd5e1',
    fontWeight: 'bold',
    fontSize: 13,
  },
  currentActionBox: {
    alignItems: 'flex-end',
  },
  toleranceIndicator: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 12,
    marginBottom: 10,
  },
  indicatorGood: {
    backgroundColor: '#10b981',
  },
  indicatorWait: {
    backgroundColor: '#f59e0b',
  },
  indicatorText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 12,
  },
  btnApprove: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  btnApproveActive: {
    backgroundColor: '#f97316',
  },
  btnApproveOverride: {
    backgroundColor: '#dc2626',
  },
  btnApproveText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  logsCard: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 20,
    padding: 22,
  },
  logsCardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 12,
  },
  noLogsText: {
    fontSize: 15,
    color: '#94a3b8',
  },
  logTextItem: {
    fontSize: 15,
    color: '#10b981',
    marginBottom: 6,
  },
  packagingCard: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 24,
    padding: 35,
    alignItems: 'center',
  },
  packagingTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 10,
  },
  packagingCustomer: {
    fontSize: 20,
    color: '#f97316',
    fontWeight: 'bold',
    marginBottom: 30,
  },
  packagingDetailsBox: {
    width: '100%',
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 16,
    padding: 25,
    marginBottom: 35,
  },
  packagingDetailItem: {
    fontSize: 16,
    color: '#cbd5e1',
    marginBottom: 12,
  },
  divider: {
    height: 1,
    backgroundColor: '#334155',
    marginVertical: 18,
  },
  calculationHighlight: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#10b981',
  },
  btnSuccessLarge: {
    width: '100%',
    backgroundColor: '#10b981',
    paddingVertical: 18,
    borderRadius: 16,
    alignItems: 'center',
  },
  btnSuccessLargeText: {
    color: '#ffffff',
    fontWeight: '800',
    fontSize: 16,
    letterSpacing: 1,
  },
  adminContainer: {
    flex: 1,
    padding: 25,
  },
  adminTabHeader: {
    flexDirection: 'row',
    backgroundColor: '#0f172a',
    borderRadius: 14,
    padding: 6,
    marginBottom: 25,
  },
  adminTabBtn: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
    borderRadius: 10,
  },
  adminTabBtnActive: {
    backgroundColor: '#2563eb', // blue-600
  },
  adminTabBtnText: {
    color: '#94a3b8',
    fontWeight: 'bold',
    fontSize: 14,
  },
  adminTabBtnTextActive: {
    color: '#ffffff',
  },
  adminScrollContent: {
    flex: 1,
  },
  adminSectionCard: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 22,
    padding: 30,
    marginBottom: 30,
  },
  adminSectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 25,
  },
  toggleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 12,
    paddingHorizontal: 18,
    paddingVertical: 15,
    marginBottom: 25,
  },
  toggleLabel: {
    color: '#ffffff',
    fontSize: 16,
  },
  toggleBtn: {
    backgroundColor: '#334155',
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: 10,
  },
  toggleBtnActive: {
    backgroundColor: '#10b981',
  },
  toggleBtnText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  btnBlue: {
    backgroundColor: '#2563eb',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 35,
  },
  btnBlueText: {
    color: '#ffffff',
    fontWeight: '800',
    fontSize: 16,
    letterSpacing: 1,
  },
  tableCard: {
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 16,
    padding: 22,
  },
  tableTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#cbd5e1',
    marginBottom: 20,
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 12,
    padding: 18,
    marginBottom: 12,
  },
  tableItemTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  tableItemSub: {
    fontSize: 14,
    color: '#94a3b8',
    marginTop: 4,
  },
  btnDelete: {
    backgroundColor: '#dc2626',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
  },
  btnDeleteText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  fieldLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#cbd5e1',
    marginBottom: 12,
  },
  selectionPills: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 25,
  },
  pillBtn: {
    backgroundColor: '#1e293b',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 20,
    paddingHorizontal: 18,
    paddingVertical: 10,
    marginRight: 10,
    marginBottom: 10,
  },
  pillBtnActive: {
    backgroundColor: '#f97316',
    borderColor: '#f97316',
  },
  pillBtnText: {
    color: '#cbd5e1',
    fontWeight: 'bold',
    fontSize: 14,
  },
  pillBtnTextActive: {
    color: '#ffffff',
  },
  recipeMasterCard: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 16,
    padding: 20,
    marginBottom: 18,
  },
  recipeMasterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  rowButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  btnToggleExpand: {
    backgroundColor: '#334155',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
    marginRight: 10,
  },
  btnToggleExpandText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  itemsSubCard: {
    marginTop: 20,
    backgroundColor: '#020617',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 14,
    padding: 18,
  },
  itemsSubCardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#f97316',
    marginBottom: 15,
  },
  itemMasterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#0f172a',
    padding: 12,
    borderRadius: 10,
    marginBottom: 10,
  },
  itemMasterText: {
    fontSize: 15,
    color: '#ffffff',
  },
  btnDeleteSmall: {
    backgroundColor: '#dc2626',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  btnDeleteSmallText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 12,
  },
  addItemForm: {
    marginTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#334155',
    paddingTop: 15,
  },
  inputFieldSmall: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#334155',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    color: '#ffffff',
    fontSize: 14,
    marginBottom: 12,
  },
  btnGreenSmall: {
    backgroundColor: '#10b981',
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
  },
  btnGreenSmallText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  orderMasterCard: {
    backgroundColor: '#0f172a',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 16,
    padding: 20,
    marginBottom: 18,
  },
  batchAdminRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#020617',
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
  },
  batchAdminText: {
    fontSize: 14,
    color: '#cbd5e1',
  },
});
