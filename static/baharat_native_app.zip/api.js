// API Client for Baharat Otomasyon Fully Native Client

class ApiClient {
  constructor() {
    this.BASE_URL = 'https://soylubaharat.kobiyz.site';
  }

  setBaseUrl(url) {
    this.BASE_URL = url.replace(/\/$/, '');
  }

  async request(endpoint, options = {}) {
    const url = `${this.BASE_URL}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...options.headers,
    };

    const config = {
      ...options,
      headers,
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || `API request failed (${response.status})`);
      }
      return data;
    } catch (error) {
      console.error(`[API Error] ${endpoint}:`, error.message);
      throw error;
    }
  }

  // --- AUTH ---
  async checkAuthStatus() {
    return this.request('/api/auth/status', { method: 'GET' });
  }

  async login(username, password, role) {
    return this.request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password, role }),
    });
  }

  async logout() {
    return this.request('/api/auth/logout', { method: 'POST' });
  }

  // --- DB STATE ---
  async fetchDb() {
    return this.request('/api/db', { method: 'GET' });
  }

  // --- USER MANAGEMENT ---
  async addUser(name, password, role) {
    return this.request('/api/users', {
      method: 'POST',
      body: JSON.stringify({ name, password, role }),
    });
  }

  async deleteUser(userId) {
    return this.request(`/api/users/${userId}`, { method: 'DELETE' });
  }

  async updateUserPermissions(userId, permissions) {
    return this.request(`/api/users/${userId}/permissions`, {
      method: 'PUT',
      body: JSON.stringify(permissions),
    });
  }

  // --- SCALE MANAGEMENT ---
  async addScale(name, ip, port, is_simulator = false) {
    return this.request('/api/scales', {
      method: 'POST',
      body: JSON.stringify({ name, ip, port, is_simulator }),
    });
  }

  async deleteScale(scaleId) {
    return this.request(`/api/scales/${scaleId}`, { method: 'DELETE' });
  }

  async testScaleConnection(ip, port, is_simulator = false) {
    return this.request('/api/scales/test-connection', {
      method: 'POST',
      body: JSON.stringify({ ip, port, is_simulator }),
    });
  }

  async connectScale(scaleId) {
    return this.request(`/api/scales/${scaleId}/connect`, { method: 'POST' });
  }

  async disconnectScale(scaleId) {
    return this.request(`/api/scales/${scaleId}/disconnect`, { method: 'POST' });
  }

  async getScaleWeight(scaleId) {
    return this.request(`/api/scales/${scaleId}/weight`, { method: 'GET' });
  }

  async setSimulatedWeight(scaleId, weight) {
    return this.request(`/api/scales/${scaleId}/weight`, {
      method: 'POST',
      body: JSON.stringify({ weight }),
    });
  }

  // --- FIRM MANAGEMENT ---
  async addFirm(name) {
    return this.request('/api/firms', {
      method: 'POST',
      body: JSON.stringify({ name }),
    });
  }

  async deleteFirm(firmId) {
    return this.request(`/api/firms/${firmId}`, { method: 'DELETE' });
  }

  // --- RECIPE MANAGEMENT ---
  async addRecipe(firmId, name) {
    return this.request('/api/recipes', {
      method: 'POST',
      body: JSON.stringify({ firmId, name }),
    });
  }

  async deleteRecipe(recipeId) {
    return this.request(`/api/recipes/${recipeId}`, { method: 'DELETE' });
  }

  async addRecipeItem(recipeId, name, amount, tolerance) {
    return this.request(`/api/recipes/${recipeId}/items`, {
      method: 'POST',
      body: JSON.stringify({ name, amount, tolerance }),
    });
  }

  async deleteRecipeItem(recipeId, itemId) {
    return this.request(`/api/recipes/${recipeId}/items/${itemId}`, { method: 'DELETE' });
  }

  // --- ORDER MANAGEMENT ---
  async createOrder(firmId, recipeId, totalAmount, bagWeight, batches) {
    return this.request('/api/orders', {
      method: 'POST',
      body: JSON.stringify({ firmId, recipeId, totalAmount, bagWeight, batches }),
    });
  }

  async deleteBatch(batchId) {
    return this.request(`/api/batches/${batchId}`, { method: 'DELETE' });
  }

  // --- WORKFLOW & LOGS ---
  async startBatch(batchId, operator) {
    return this.request(`/api/batches/${batchId}/start`, {
      method: 'POST',
      body: JSON.stringify({ operator }),
    });
  }

  async finishBatch(batchId) {
    return this.request(`/api/batches/${batchId}/finish`, { method: 'POST' });
  }

  async updateBatchStatus(batchId, status) {
    return this.request(`/api/batches/${batchId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  }

  async addLog(batchId, operator, customer, recipe, item, target, actual, status) {
    return this.request('/api/logs', {
      method: 'POST',
      body: JSON.stringify({ batchId, operator, customer, recipe, item, target, actual, status }),
    });
  }
}

export const api = new ApiClient();
